import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Navigation from "@/components/navigation";
import ProductCard from "@/components/product-card";
import VoiceDemo from "@/components/voice-demo";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { ShoppingCart, Truck, CheckCircle, Clock, TrendingUp, Users, Star } from "lucide-react";

export default function Home() {
  const { user, isLoading } = useAuth();
  const { toast } = useToast();

  // Fetch featured products
  const { data: products = [], isLoading: productsLoading } = useQuery({
    queryKey: ['/api/products'],
    enabled: !!user,
  });

  // Fetch user orders
  const { data: orders = [] } = useQuery({
    queryKey: ['/api/orders'],
    enabled: !!user,
  });

  useEffect(() => {
    if (!isLoading && !user) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [user, isLoading, toast]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="spinner"></div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const recentOrders = orders.slice(0, 3);
  const featuredProducts = products.slice(0, 8);

  const getOrderStatusColor = (status: string) => {
    switch (status) {
      case 'delivered': return 'bg-green-100 text-green-800';
      case 'shipped': return 'bg-blue-100 text-blue-800';
      case 'in_production': return 'bg-yellow-100 text-yellow-800';
      case 'pending': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const orderStats = {
    total: orders.length,
    pending: orders.filter(o => o.status === 'pending').length,
    inProduction: orders.filter(o => o.status === 'in_production').length,
    shipped: orders.filter(o => o.status === 'shipped').length,
    delivered: orders.filter(o => o.status === 'delivered').length,
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      {/* Hero Section */}
      <section className="gradient-primary text-white py-16">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl md:text-6xl font-bold mb-6">
                Welcome back, {user.firstName || 'Customer'}!
              </h1>
              <p className="text-xl text-primary-100 mb-8">
                Discover new AI-powered furniture or manage your existing orders in your personalized dashboard.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/products">
                  <Button size="lg" className="bg-accent-coral hover:bg-red-600">
                    <ShoppingCart className="mr-2" size={20} />
                    Shop Now
                  </Button>
                </Link>
                <Link href="/orders">
                  <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-primary-500">
                    View Orders
                  </Button>
                </Link>
              </div>
            </div>

            <div className="flex justify-center">
              <VoiceDemo />
            </div>
          </div>
        </div>
      </section>

      {/* Dashboard Stats */}
      <section className="py-12">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-600 text-sm">Total Orders</p>
                    <p className="text-3xl font-bold text-primary-500">{orderStats.total}</p>
                  </div>
                  <div className="bg-accent-coral p-3 rounded-full">
                    <ShoppingCart className="text-white" size={20} />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-600 text-sm">In Production</p>
                    <p className="text-3xl font-bold text-primary-500">{orderStats.inProduction}</p>
                  </div>
                  <div className="bg-yellow-500 p-3 rounded-full">
                    <Clock className="text-white" size={20} />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-600 text-sm">Shipped</p>
                    <p className="text-3xl font-bold text-primary-500">{orderStats.shipped}</p>
                  </div>
                  <div className="bg-blue-500 p-3 rounded-full">
                    <Truck className="text-white" size={20} />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-600 text-sm">Delivered</p>
                    <p className="text-3xl font-bold text-primary-500">{orderStats.delivered}</p>
                  </div>
                  <div className="bg-green-500 p-3 rounded-full">
                    <CheckCircle className="text-white" size={20} />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Orders */}
          {recentOrders.length > 0 && (
            <Card className="mb-12">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Recent Orders</CardTitle>
                  <Link href="/orders">
                    <Button variant="outline" size="sm">View All</Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentOrders.map((order) => (
                    <div key={order.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                      <div>
                        <p className="font-semibold">Order #{order.id.slice(0, 8)}</p>
                        <p className="text-sm text-gray-600">
                          {new Date(order.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="text-right">
                        <Badge className={getOrderStatusColor(order.status)}>
                          {order.status.replace('_', ' ').charAt(0).toUpperCase() + order.status.slice(1)}
                        </Badge>
                        <p className="text-sm text-gray-600 mt-1">
                          ${order.estimatedCost || order.finalCost}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Featured Products */}
          <div className="mb-12">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-3xl font-bold text-gray-800">Featured Products</h2>
              <Link href="/products">
                <Button variant="outline">View All Products</Button>
              </Link>
            </div>

            {productsLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {[...Array(4)].map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <div className="bg-gray-300 h-48 rounded-t-lg"></div>
                    <CardContent className="p-6">
                      <div className="h-4 bg-gray-300 rounded mb-2"></div>
                      <div className="h-3 bg-gray-300 rounded mb-4"></div>
                      <div className="h-8 bg-gray-300 rounded"></div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {featuredProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            )}
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="card-hover cursor-pointer" onClick={() => window.location.href = '/products'}>
              <CardContent className="p-8 text-center">
                <TrendingUp className="mx-auto mb-4 text-accent-coral" size={48} />
                <h3 className="text-xl font-bold mb-2">Browse Products</h3>
                <p className="text-gray-600">Explore our latest AI-powered furniture collection</p>
              </CardContent>
            </Card>

            <Card className="card-hover cursor-pointer" onClick={() => window.location.href = '/support'}>
              <CardContent className="p-8 text-center">
                <Users className="mx-auto mb-4 text-blue-500" size={48} />
                <h3 className="text-xl font-bold mb-2">Customer Support</h3>
                <p className="text-gray-600">Get help with your orders and products</p>
              </CardContent>
            </Card>

            <Card className="card-hover cursor-pointer" onClick={() => window.location.href = '/vendor'}>
              <CardContent className="p-8 text-center">
                <Star className="mx-auto mb-4 text-yellow-500" size={48} />
                <h3 className="text-xl font-bold mb-2">Become a Vendor</h3>
                <p className="text-gray-600">Join our marketplace and sell your furniture</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
