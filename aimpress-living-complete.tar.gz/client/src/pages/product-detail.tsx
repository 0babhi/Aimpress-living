import { useState, useEffect } from "react";
import { useParams } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import Navigation from "@/components/navigation";
import ARViewer from "@/components/ar-viewer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import {
  Heart,
  Share2,
  ShoppingCart,
  Box,
  Camera,
  Headset,
  Star,
  Mic,
  Home,
  Users,
  Package,
  Truck,
  Shield,
  ArrowLeft,
  Plus,
  Minus,
  MessageCircle
} from "lucide-react";
import type { Product, Review } from "@shared/schema";

export default function ProductDetail() {
  const params = useParams();
  const productId = params.id;
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [showARViewer, setShowARViewer] = useState(false);
  const [customizations, setCustomizations] = useState({
    material: '',
    color: '',
    dimensions: '',
    voiceLanguage: 'english',
    specialRequests: ''
  });

  // Fetch product details
  const { data: product, isLoading: productLoading } = useQuery({
    queryKey: ['/api/products', productId],
    queryFn: async () => {
      const response = await fetch(`/api/products/${productId}`);
      if (!response.ok) throw new Error('Product not found');
      return response.json() as Product;
    },
    enabled: !!productId,
  });

  // Fetch product reviews
  const { data: reviews = [], isLoading: reviewsLoading } = useQuery({
    queryKey: ['/api/products', productId, 'reviews'],
    queryFn: async () => {
      const response = await fetch(`/api/products/${productId}/reviews`);
      if (!response.ok) throw new Error('Failed to fetch reviews');
      return response.json() as Review[];
    },
    enabled: !!productId,
  });

  // Create order mutation
  const createOrderMutation = useMutation({
    mutationFn: async (orderData: any) => {
      const response = await apiRequest('POST', '/api/orders', orderData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Order Created!",
        description: "Your custom order has been sent to our vendors for review.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/orders'] });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Order Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Add to cart mutation
  const addToCartMutation = useMutation({
    mutationFn: async () => {
      // TODO: Implement cart functionality
      console.log("Adding to cart:", { productId, quantity, customizations });
    },
    onSuccess: () => {
      toast({
        title: "Added to Cart!",
        description: "Product has been added to your cart.",
      });
    },
  });

  const handleCustomOrder = () => {
    if (!isAuthenticated) {
      toast({
        title: "Sign In Required",
        description: "Please sign in to place a custom order.",
        variant: "destructive",
      });
      return;
    }

    createOrderMutation.mutate({
      productId: product?.id,
      vendorId: product?.vendorId,
      customizations,
      estimatedCost: calculateEstimatedCost(),
      notes: customizations.specialRequests,
    });
  };

  const handleAddToCart = () => {
    if (!isAuthenticated) {
      toast({
        title: "Sign In Required",
        description: "Please sign in to add items to cart.",
        variant: "destructive",
      });
      return;
    }

    addToCartMutation.mutate();
  };

  const calculateEstimatedCost = () => {
    if (!product) return 0;
    const basePrice = parseFloat(product.basePrice);
    let total = basePrice * quantity;

    // Add customization costs (simplified calculation)
    if (customizations.material === 'premium') total *= 1.2;
    if (customizations.dimensions) total *= 1.1;

    return total;
  };

  const formatPrice = (price: string | number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(typeof price === 'string' ? parseFloat(price) : price);
  };

  const handleVoiceCommand = (command: string) => {
    toast({
      title: "Voice Command Demo",
      description: `Simulating: "${command}"`,
    });
  };

  if (productLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <div className="container mx-auto px-6 py-8">
          <div className="animate-pulse">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="bg-gray-300 h-96 rounded-lg"></div>
              <div className="space-y-4">
                <div className="h-8 bg-gray-300 rounded"></div>
                <div className="h-4 bg-gray-300 rounded w-3/4"></div>
                <div className="h-6 bg-gray-300 rounded w-1/2"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <div className="container mx-auto px-6 py-8">
          <Card>
            <CardContent className="p-12 text-center">
              <Package className="mx-auto mb-4 text-gray-400" size={48} />
              <h3 className="text-xl font-semibold text-gray-600 mb-2">Product not found</h3>
              <p className="text-gray-500">The product you're looking for doesn't exist or has been removed.</p>
              <Button className="mt-4" onClick={() => window.history.back()}>
                <ArrowLeft className="mr-2" size={16} />
                Go Back
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const images = product.imageUrls && Array.isArray(product.imageUrls) 
    ? product.imageUrls 
    : ["https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"];

  const voiceCommands = product.voiceCommands && Array.isArray(product.voiceCommands) 
    ? product.voiceCommands 
    : ["Move forward", "Adjust height", "Change mode", "Status update"];

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-6 py-4">
          <nav className="text-sm text-gray-600">
            <span>Home</span> / <span>Products</span> / <span>{product.category}</span> / 
            <span className="text-gray-900 font-medium"> {product.name}</span>
          </nav>
        </div>
      </div>

      <div className="container mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Product Images */}
          <div className="space-y-4">
            <div className="relative">
              <img
                src={images[selectedImage]}
                alt={product.name}
                className="w-full h-96 object-cover rounded-lg shadow-lg"
              />
              
              {/* Image Controls */}
              <div className="absolute top-4 right-4 space-y-2">
                <Button
                  variant="secondary"
                  size="sm"
                  className="bg-white bg-opacity-90"
                  onClick={() => setShowARViewer(true)}
                >
                  <Camera className="mr-2" size={16} />
                  AR View
                </Button>
                <Button
                  variant="secondary"
                  size="sm"
                  className="bg-white bg-opacity-90"
                >
                  <Box className="mr-2" size={16} />
                  3D View
                </Button>
                <Button
                  variant="secondary"
                  size="sm"
                  className="bg-white bg-opacity-90"
                >
                  <Headset className="mr-2" size={16} />
                  VR
                </Button>
              </div>

              {/* Wishlist & Share */}
              <div className="absolute top-4 left-4 space-y-2">
                <Button
                  variant="secondary"
                  size="sm"
                  className={`bg-white bg-opacity-90 ${isWishlisted ? 'text-red-500' : ''}`}
                  onClick={() => setIsWishlisted(!isWishlisted)}
                >
                  <Heart fill={isWishlisted ? 'currentColor' : 'none'} size={16} />
                </Button>
                <Button
                  variant="secondary"
                  size="sm"
                  className="bg-white bg-opacity-90"
                >
                  <Share2 size={16} />
                </Button>
              </div>
            </div>

            {/* Thumbnail Images */}
            <div className="flex space-x-2 overflow-x-auto">
              {images.map((image, index) => (
                <img
                  key={index}
                  src={image}
                  alt={`${product.name} ${index + 1}`}
                  className={`w-20 h-20 object-cover rounded-lg cursor-pointer ${
                    selectedImage === index ? 'ring-2 ring-accent-coral' : ''
                  }`}
                  onClick={() => setSelectedImage(index)}
                />
              ))}
            </div>
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <div className="flex items-center space-x-2 mb-2">
                <Badge className="bg-accent-coral text-white">AI Enabled</Badge>
                <Badge variant="outline">{product.category}</Badge>
              </div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">{product.name}</h1>
              <p className="text-gray-600 text-lg">{product.description}</p>
            </div>

            {/* Rating */}
            <div className="flex items-center space-x-4">
              <div className="flex items-center">
                <div className="flex text-yellow-500">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      size={20}
                      fill={i < Math.floor(parseFloat(product.rating || '0')) ? 'currentColor' : 'none'}
                    />
                  ))}
                </div>
                <span className="ml-2 text-gray-600">
                  {product.rating} ({product.reviewCount} reviews)
                </span>
              </div>
              <Button variant="link" className="text-accent-coral p-0">
                Read Reviews
              </Button>
            </div>

            {/* Price */}
            <div className="border-t border-b py-4">
              <div className="text-3xl font-bold text-primary-500 mb-2">
                {formatPrice(product.basePrice)}
              </div>
              <p className="text-gray-600">
                Starting price for base configuration. Final price varies with customizations.
              </p>
            </div>

            {/* AI Features */}
            <div>
              <h3 className="text-lg font-semibold mb-3">AI Features</h3>
              <div className="grid grid-cols-2 gap-3">
                {product.aiFeatures && Array.isArray(product.aiFeatures) && product.aiFeatures.map((feature) => (
                  <div key={feature} className="flex items-center space-x-2 p-2 bg-gray-50 rounded-lg">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-sm font-medium">
                      {feature.replace('_', ' ').charAt(0).toUpperCase() + feature.slice(1)}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Voice Commands Demo */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Mic className="mr-2 text-accent-coral" size={20} />
                  Voice Commands
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {voiceCommands.slice(0, 3).map((command, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-2 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer"
                      onClick={() => handleVoiceCommand(command)}
                    >
                      <span className="text-sm">"{command}"</span>
                      <Button variant="ghost" size="sm">
                        <Mic size={14} />
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quantity & Actions */}
            <div className="space-y-4">
              <div className="flex items-center space-x-4">
                <Label htmlFor="quantity">Quantity:</Label>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  >
                    <Minus size={16} />
                  </Button>
                  <Input
                    id="quantity"
                    type="number"
                    value={quantity}
                    onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-20 text-center"
                    min="1"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setQuantity(quantity + 1)}
                  >
                    <Plus size={16} />
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <Button
                  size="lg"
                  className="bg-accent-coral hover:bg-red-600"
                  onClick={handleAddToCart}
                  disabled={addToCartMutation.isPending}
                >
                  <ShoppingCart className="mr-2" size={20} />
                  Add to Cart
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  onClick={handleCustomOrder}
                  disabled={createOrderMutation.isPending}
                >
                  <MessageCircle className="mr-2" size={20} />
                  Custom Order
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Product Details Tabs */}
        <div className="mt-12">
          <Tabs defaultValue="details" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="details">Details</TabsTrigger>
              <TabsTrigger value="customization">Customization</TabsTrigger>
              <TabsTrigger value="reviews">Reviews ({reviews.length})</TabsTrigger>
              <TabsTrigger value="support">Support</TabsTrigger>
            </TabsList>

            <TabsContent value="details" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <Card>
                  <CardHeader>
                    <CardTitle>Product Specifications</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex justify-between">
                      <span className="font-medium">Category:</span>
                      <span>{product.category}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Customizable:</span>
                      <span>{product.customizable ? 'Yes' : 'No'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">In Stock:</span>
                      <span className={product.inStock ? 'text-green-600' : 'text-red-600'}>
                        {product.inStock ? 'Available' : 'Out of Stock'}
                      </span>
                    </div>
                    <Separator />
                    <div>
                      <span className="font-medium">Materials Available:</span>
                      <div className="mt-2 space-y-1">
                        {product.materials && typeof product.materials === 'object' ? (
                          Object.keys(product.materials).map((material) => (
                            <Badge key={material} variant="outline" className="mr-2">
                              {material}
                            </Badge>
                          ))
                        ) : (
                          <span className="text-gray-500">Standard materials</span>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Smart Features</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <Home className="text-blue-500" size={16} />
                      <span>Smart Home Integration</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Mic className="text-accent-coral" size={16} />
                      <span>Voice Control</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Users className="text-green-500" size={16} />
                      <span>Multi-User Recognition</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Shield className="text-purple-500" size={16} />
                      <span>Privacy Protection</span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="customization" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Customize Your Order</CardTitle>
                  <p className="text-gray-600">
                    Personalize this product to match your specific needs and preferences.
                  </p>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="material">Material</Label>
                      <Select value={customizations.material} onValueChange={(value) => 
                        setCustomizations(prev => ({ ...prev, material: value }))
                      }>
                        <SelectTrigger>
                          <SelectValue placeholder="Select material" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="standard">Standard Wood</SelectItem>
                          <SelectItem value="premium">Premium Oak</SelectItem>
                          <SelectItem value="metal">Metal Frame</SelectItem>
                          <SelectItem value="composite">Composite Material</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="color">Color</Label>
                      <Select value={customizations.color} onValueChange={(value) => 
                        setCustomizations(prev => ({ ...prev, color: value }))
                      }>
                        <SelectTrigger>
                          <SelectValue placeholder="Select color" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="natural">Natural Wood</SelectItem>
                          <SelectItem value="dark">Dark Brown</SelectItem>
                          <SelectItem value="white">White</SelectItem>
                          <SelectItem value="black">Black</SelectItem>
                          <SelectItem value="custom">Custom Color</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="dimensions">Custom Dimensions</Label>
                      <Input
                        id="dimensions"
                        placeholder="e.g., 48L x 24W x 30H inches"
                        value={customizations.dimensions}
                        onChange={(e) => setCustomizations(prev => ({ ...prev, dimensions: e.target.value }))}
                      />
                    </div>

                    <div>
                      <Label htmlFor="voiceLanguage">Voice Language</Label>
                      <Select value={customizations.voiceLanguage} onValueChange={(value) => 
                        setCustomizations(prev => ({ ...prev, voiceLanguage: value }))
                      }>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="english">English</SelectItem>
                          <SelectItem value="spanish">Spanish</SelectItem>
                          <SelectItem value="french">French</SelectItem>
                          <SelectItem value="german">German</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="specialRequests">Special Requests</Label>
                    <Textarea
                      id="specialRequests"
                      placeholder="Any special requirements or modifications..."
                      value={customizations.specialRequests}
                      onChange={(e) => setCustomizations(prev => ({ ...prev, specialRequests: e.target.value }))}
                      rows={4}
                    />
                  </div>

                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-semibold mb-2">Estimated Total</h4>
                    <div className="text-2xl font-bold text-primary-500">
                      {formatPrice(calculateEstimatedCost())}
                    </div>
                    <p className="text-sm text-gray-600">
                      Final price will be confirmed by vendor
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="reviews" className="mt-6">
              <div className="space-y-6">
                {reviewsLoading ? (
                  <div className="space-y-4">
                    {[...Array(3)].map((_, i) => (
                      <Card key={i} className="animate-pulse">
                        <CardContent className="p-6">
                          <div className="h-4 bg-gray-300 rounded mb-2"></div>
                          <div className="h-3 bg-gray-300 rounded w-3/4"></div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : reviews.length === 0 ? (
                  <Card>
                    <CardContent className="p-12 text-center">
                      <Star className="mx-auto mb-4 text-gray-400" size={48} />
                      <h3 className="text-xl font-semibold text-gray-600 mb-2">No reviews yet</h3>
                      <p className="text-gray-500">Be the first to review this product!</p>
                    </CardContent>
                  </Card>
                ) : (
                  reviews.map((review) => (
                    <Card key={review.id}>
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex items-center space-x-2">
                            <div className="flex text-yellow-500">
                              {[...Array(5)].map((_, i) => (
                                <Star
                                  key={i}
                                  size={16}
                                  fill={i < review.rating ? 'currentColor' : 'none'}
                                />
                              ))}
                            </div>
                            <span className="font-medium">{review.title}</span>
                          </div>
                          <span className="text-sm text-gray-500">
                            {new Date(review.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                        <p className="text-gray-600">{review.content}</p>
                        {review.isVerified && (
                          <Badge className="mt-2 bg-green-100 text-green-800">
                            Verified Purchase
                          </Badge>
                        )}
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>

            <TabsContent value="support" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Product Support</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center space-x-2 p-3 bg-gray-50 rounded-lg">
                      <Package className="text-blue-500" size={20} />
                      <div>
                        <p className="font-medium">Installation Guide</p>
                        <p className="text-sm text-gray-600">Step-by-step setup instructions</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 p-3 bg-gray-50 rounded-lg">
                      <Truck className="text-green-500" size={20} />
                      <div>
                        <p className="font-medium">Delivery Information</p>
                        <p className="text-sm text-gray-600">Shipping and delivery details</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 p-3 bg-gray-50 rounded-lg">
                      <Shield className="text-purple-500" size={20} />
                      <div>
                        <p className="font-medium">Warranty</p>
                        <p className="text-sm text-gray-600">2-year manufacturer warranty</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Need Help?</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button variant="outline" className="w-full justify-start">
                      <MessageCircle className="mr-2" size={16} />
                      Chat with Support
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Headset className="mr-2" size={16} />
                      Schedule Video Call
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Package className="mr-2" size={16} />
                      Request Demo
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* AR Viewer Modal */}
      {showARViewer && (
        <ARViewer
          product={product}
          onClose={() => setShowARViewer(false)}
        />
      )}
    </div>
  );
}
