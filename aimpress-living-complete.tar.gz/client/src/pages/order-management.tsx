import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import Navigation from "@/components/navigation";
import OrderTable from "@/components/order-table";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  ShoppingBag,
  Cog,
  Truck,
  CheckCircle,
  Filter,
  RefreshCw,
  Plus,
  Download,
  Search,
  Calendar
} from "lucide-react";

export default function OrderManagement() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [statusFilter, setStatusFilter] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [dateRange, setDateRange] = useState('');

  // Fetch orders
  const { data: orders = [], isLoading: ordersLoading, refetch } = useQuery({
    queryKey: ['/api/orders'],
    enabled: isAuthenticated,
  });

  // Update order status mutation
  const updateOrderMutation = useMutation({
    mutationFn: async ({ orderId, status, updates }: { orderId: string; status: string; updates?: any }) => {
      const response = await apiRequest('PATCH', `/api/orders/${orderId}/status`, { status, ...updates });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Order Updated",
        description: "Order status has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/orders'] });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [isAuthenticated, isLoading, toast]);

  const handleRefresh = () => {
    refetch();
    toast({
      title: "Refreshed",
      description: "Order data has been refreshed.",
    });
  };

  const handleExport = () => {
    // TODO: Implement export functionality
    toast({
      title: "Export Started",
      description: "Your order export is being prepared.",
    });
  };

  const handleCreateNewOrder = () => {
    // TODO: Navigate to product selection or show modal
    window.location.href = '/products';
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <div className="container mx-auto px-6 py-8">
          <div className="spinner mx-auto"></div>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  // Filter orders based on current filters
  const filteredOrders = orders.filter(order => {
    const matchesStatus = !statusFilter || order.status === statusFilter;
    const matchesSearch = !searchQuery || 
      order.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (order.customerId && order.customerId.toLowerCase().includes(searchQuery.toLowerCase()));
    
    // TODO: Implement date range filtering
    const matchesDate = true;

    return matchesStatus && matchesSearch && matchesDate;
  });

  // Calculate order statistics
  const orderStats = {
    total: orders.length,
    pending: orders.filter(o => o.status === 'pending').length,
    inProduction: orders.filter(o => o.status === 'in_production').length,
    shipped: orders.filter(o => o.status === 'shipped').length,
    delivered: orders.filter(o => o.status === 'delivered').length,
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'delivered': return 'bg-green-100 text-green-800';
      case 'shipped': return 'bg-blue-100 text-blue-800';
      case 'in_production': return 'bg-yellow-100 text-yellow-800';
      case 'pending': return 'bg-gray-100 text-gray-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      {/* Header */}
      <section className="bg-white border-b">
        <div className="container mx-auto px-6 py-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Order Management</h1>
              <p className="text-gray-600 mt-2">
                Track your orders, manage delivery, and get real-time updates on your smart furniture
              </p>
            </div>
            <div className="flex space-x-4">
              <Button onClick={handleCreateNewOrder} className="bg-accent-coral hover:bg-red-600">
                <Plus className="mr-2" size={16} />
                New Order
              </Button>
              <Button variant="outline" onClick={handleExport}>
                <Download className="mr-2" size={16} />
                Export
              </Button>
            </div>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-6 py-8">
        {/* Order Statistics */}
        <div className="gradient-primary rounded-2xl p-8 text-white mb-8">
          <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between mb-8">
            <div>
              <h3 className="text-2xl font-bold mb-2">Your Orders</h3>
              <p className="text-primary-100">Manage and track all your AI furniture orders</p>
            </div>
            <div className="flex space-x-4 mt-4 lg:mt-0">
              <Button
                variant="secondary"
                className="bg-white text-primary-500 hover:bg-gray-100"
                onClick={handleRefresh}
              >
                <RefreshCw className="mr-2" size={16} />
                Refresh
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="bg-white bg-opacity-10 backdrop-blur-md rounded-xl p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-primary-100 text-sm">Total Orders</p>
                  <p className="text-3xl font-bold">{orderStats.total}</p>
                </div>
                <div className="bg-accent-coral p-3 rounded-full">
                  <ShoppingBag className="text-white" size={20} />
                </div>
              </div>
            </div>
            
            <div className="bg-white bg-opacity-10 backdrop-blur-md rounded-xl p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-primary-100 text-sm">In Production</p>
                  <p className="text-3xl font-bold">{orderStats.inProduction}</p>
                </div>
                <div className="bg-yellow-500 p-3 rounded-full">
                  <Cog className="text-white" size={20} />
                </div>
              </div>
            </div>
            
            <div className="bg-white bg-opacity-10 backdrop-blur-md rounded-xl p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-primary-100 text-sm">Shipped</p>
                  <p className="text-3xl font-bold">{orderStats.shipped}</p>
                </div>
                <div className="bg-blue-500 p-3 rounded-full">
                  <Truck className="text-white" size={20} />
                </div>
              </div>
            </div>
            
            <div className="bg-white bg-opacity-10 backdrop-blur-md rounded-xl p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-primary-100 text-sm">Delivered</p>
                  <p className="text-3xl font-bold">{orderStats.delivered}</p>
                </div>
                <div className="bg-green-500 p-3 rounded-full">
                  <CheckCircle className="text-white" size={20} />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Filters and Search */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-wrap gap-4 items-center">
              <div className="relative min-w-[200px]">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
                <Input
                  placeholder="Search orders..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>

              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="All Statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Statuses</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="accepted">Accepted</SelectItem>
                  <SelectItem value="in_production">In Production</SelectItem>
                  <SelectItem value="shipped">Shipped</SelectItem>
                  <SelectItem value="delivered">Delivered</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>

              <Select value={dateRange} onValueChange={setDateRange}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Date Range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Time</SelectItem>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="week">This Week</SelectItem>
                  <SelectItem value="month">This Month</SelectItem>
                  <SelectItem value="quarter">This Quarter</SelectItem>
                </SelectContent>
              </Select>

              {(statusFilter || searchQuery || dateRange) && (
                <Button
                  variant="outline"
                  onClick={() => {
                    setStatusFilter('');
                    setSearchQuery('');
                    setDateRange('');
                  }}
                >
                  <Filter className="mr-2" size={16} />
                  Clear Filters
                </Button>
              )}
            </div>

            {/* Active Filters */}
            {(statusFilter || searchQuery || dateRange) && (
              <div className="mt-4 pt-4 border-t">
                <p className="text-sm text-gray-600 mb-2">Active filters:</p>
                <div className="flex flex-wrap gap-2">
                  {statusFilter && (
                    <Badge variant="secondary">
                      Status: {statusFilter}
                    </Badge>
                  )}
                  {searchQuery && (
                    <Badge variant="secondary">
                      Search: "{searchQuery}"
                    </Badge>
                  )}
                  {dateRange && (
                    <Badge variant="secondary">
                      Date: {dateRange}
                    </Badge>
                  )}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Orders Content */}
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="all">All Orders ({filteredOrders.length})</TabsTrigger>
            <TabsTrigger value="pending">Pending ({orderStats.pending})</TabsTrigger>
            <TabsTrigger value="active">Active ({orderStats.inProduction + orderStats.shipped})</TabsTrigger>
            <TabsTrigger value="completed">Completed ({orderStats.delivered})</TabsTrigger>
            <TabsTrigger value="tracking">Tracking</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="mt-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>All Orders</CardTitle>
                  <div className="flex space-x-2">
                    <Button variant="ghost" size="sm" onClick={handleRefresh}>
                      <RefreshCw size={16} />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Filter size={16} />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {ordersLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <div className="spinner"></div>
                  </div>
                ) : (
                  <OrderTable 
                    orders={filteredOrders} 
                    isVendor={user?.role === 'vendor'} 
                    onUpdateOrder={(orderId, status, updates) => 
                      updateOrderMutation.mutate({ orderId, status, updates })
                    }
                  />
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="pending" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Pending Orders</CardTitle>
              </CardHeader>
              <CardContent>
                <OrderTable 
                  orders={filteredOrders.filter(o => o.status === 'pending')} 
                  isVendor={user?.role === 'vendor'}
                  onUpdateOrder={(orderId, status, updates) => 
                    updateOrderMutation.mutate({ orderId, status, updates })
                  }
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="active" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Active Orders</CardTitle>
              </CardHeader>
              <CardContent>
                <OrderTable 
                  orders={filteredOrders.filter(o => ['in_production', 'shipped'].includes(o.status))} 
                  isVendor={user?.role === 'vendor'}
                  onUpdateOrder={(orderId, status, updates) => 
                    updateOrderMutation.mutate({ orderId, status, updates })
                  }
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="completed" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Completed Orders</CardTitle>
              </CardHeader>
              <CardContent>
                <OrderTable 
                  orders={filteredOrders.filter(o => o.status === 'delivered')} 
                  isVendor={user?.role === 'vendor'}
                  onUpdateOrder={(orderId, status, updates) => 
                    updateOrderMutation.mutate({ orderId, status, updates })
                  }
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tracking" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Order Tracking</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {filteredOrders.filter(o => ['shipped', 'in_production'].includes(o.status)).map((order) => (
                    <div key={order.id} className="border rounded-lg p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <h4 className="font-semibold">Order #{order.id.slice(0, 8)}</h4>
                          <p className="text-sm text-gray-600">
                            Placed on {new Date(order.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <Badge className={getStatusColor(order.status)}>
                          {order.status.replace('_', ' ').charAt(0).toUpperCase() + order.status.slice(1)}
                        </Badge>
                      </div>
                      
                      {/* Order Progress Timeline */}
                      <div className="space-y-3">
                        <div className="flex items-center space-x-3">
                          <div className="w-4 h-4 bg-green-500 rounded-full"></div>
                          <span className="text-sm">Order Placed</span>
                          <span className="text-xs text-gray-500">
                            {new Date(order.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                        
                        <div className="flex items-center space-x-3">
                          <div className={`w-4 h-4 rounded-full ${
                            ['accepted', 'in_production', 'shipped', 'delivered'].includes(order.status) 
                              ? 'bg-green-500' : 'bg-gray-300'
                          }`}></div>
                          <span className="text-sm">Order Accepted</span>
                        </div>
                        
                        <div className="flex items-center space-x-3">
                          <div className={`w-4 h-4 rounded-full ${
                            ['in_production', 'shipped', 'delivered'].includes(order.status) 
                              ? 'bg-green-500' : 'bg-gray-300'
                          }`}></div>
                          <span className="text-sm">In Production</span>
                        </div>
                        
                        <div className="flex items-center space-x-3">
                          <div className={`w-4 h-4 rounded-full ${
                            ['shipped', 'delivered'].includes(order.status) 
                              ? 'bg-green-500' : 'bg-gray-300'
                          }`}></div>
                          <span className="text-sm">Shipped</span>
                        </div>
                        
                        <div className="flex items-center space-x-3">
                          <div className={`w-4 h-4 rounded-full ${
                            order.status === 'delivered' ? 'bg-green-500' : 'bg-gray-300'
                          }`}></div>
                          <span className="text-sm">Delivered</span>
                        </div>
                      </div>
                      
                      {order.deadline && (
                        <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                          <p className="text-sm text-blue-800">
                            <Calendar className="inline mr-2" size={16} />
                            Expected delivery: {new Date(order.deadline).toLocaleDateString()}
                          </p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
