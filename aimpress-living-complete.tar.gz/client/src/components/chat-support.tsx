import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Bot,
  User,
  Send,
  Paperclip,
  Phone,
  Video,
  MoreVertical,
  CheckCheck,
  Clock,
  AlertCircle
} from "lucide-react";

interface Message {
  id: string;
  content: string;
  senderId: string;
  isFromPlatform: boolean;
  timestamp: Date;
  status?: 'sending' | 'sent' | 'delivered' | 'read';
  type?: 'text' | 'system' | 'handoff';
}

interface ChatSupportProps {
  orderId?: string;
  className?: string;
}

export default function ChatSupport({ orderId, className = "" }: ChatSupportProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [isConnected, setIsConnected] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [agentInfo, setAgentInfo] = useState<{ name: string; status: string } | null>(null);
  const [connectionStatus, setConnectionStatus] = useState<'connecting' | 'connected' | 'disconnected'>('connecting');
  
  const wsRef = useRef<WebSocket | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Initialize WebSocket connection
  useEffect(() => {
    if (!user) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    try {
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        setConnectionStatus('connected');
        setIsConnected(true);
        
        // Join support room
        ws.send(JSON.stringify({
          type: 'join_support',
          userId: user.id,
          orderId: orderId || null,
        }));

        // Add welcome message
        addSystemMessage("Connected to AI Support. How can we help you today?");
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          handleWebSocketMessage(data);
        } catch (error) {
          console.error('Failed to parse WebSocket message:', error);
        }
      };

      ws.onclose = () => {
        setConnectionStatus('disconnected');
        setIsConnected(false);
        setAgentInfo(null);
      };

      ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        setConnectionStatus('disconnected');
        toast({
          title: "Connection Error",
          description: "Failed to connect to support chat. Please try again.",
          variant: "destructive",
        });
      };
    } catch (error) {
      console.error('Failed to create WebSocket connection:', error);
      setConnectionStatus('disconnected');
    }

    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [user, orderId, toast]);

  // Auto scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleWebSocketMessage = (data: any) => {
    switch (data.type) {
      case 'new_message':
        addMessage({
          id: data.message.id || Date.now().toString(),
          content: data.message.content,
          senderId: data.message.senderId,
          isFromPlatform: data.message.isFromPlatform || false,
          timestamp: new Date(data.message.createdAt || Date.now()),
          status: 'delivered',
        });
        break;

      case 'agent_typing':
        setIsTyping(data.isTyping);
        if (data.agent) {
          setAgentInfo(data.agent);
        }
        break;

      case 'agent_connected':
        setAgentInfo(data.agent);
        addSystemMessage(`${data.agent.name} has joined the conversation`);
        break;

      case 'agent_disconnected':
        if (agentInfo) {
          addSystemMessage(`${agentInfo.name} has left the conversation`);
        }
        setAgentInfo(null);
        break;

      case 'handoff_to_human':
        addSystemMessage("Connecting you to a human agent...", 'handoff');
        break;

      case 'ai_response':
        addMessage({
          id: Date.now().toString(),
          content: data.content,
          senderId: 'ai-assistant',
          isFromPlatform: true,
          timestamp: new Date(),
          status: 'delivered',
        });
        break;

      default:
        console.log('Unknown message type:', data.type);
    }
  };

  const addMessage = (message: Message) => {
    setMessages(prev => [...prev, message]);
  };

  const addSystemMessage = (content: string, type: 'system' | 'handoff' = 'system') => {
    addMessage({
      id: Date.now().toString(),
      content,
      senderId: 'system',
      isFromPlatform: true,
      timestamp: new Date(),
      status: 'delivered',
      type,
    });
  };

  const sendMessage = () => {
    if (!newMessage.trim() || !wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
      return;
    }

    const message: Message = {
      id: Date.now().toString(),
      content: newMessage.trim(),
      senderId: user?.id || 'anonymous',
      isFromPlatform: false,
      timestamp: new Date(),
      status: 'sending',
    };

    // Add message to UI immediately
    addMessage(message);

    // Send via WebSocket
    wsRef.current.send(JSON.stringify({
      type: 'send_message',
      content: newMessage.trim(),
      senderId: user?.id,
      receiverId: agentInfo ? agentInfo.name : 'ai-assistant',
      orderId: orderId || null,
      isFromPlatform: false,
    }));

    setNewMessage("");

    // Update message status after a delay (simulate network)
    setTimeout(() => {
      setMessages(prev => prev.map(msg => 
        msg.id === message.id ? { ...msg, status: 'sent' } : msg
      ));
    }, 500);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const requestHumanAgent = () => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'request_human_agent',
        userId: user?.id,
        orderId: orderId || null,
      }));
    }
  };

  const getMessageIcon = (message: Message) => {
    if (message.type === 'system' || message.type === 'handoff') {
      return <AlertCircle size={16} className="text-blue-500" />;
    }
    
    if (message.senderId === 'ai-assistant') {
      return <Bot size={16} className="text-primary-500" />;
    }
    
    if (message.isFromPlatform && agentInfo) {
      return <User size={16} className="text-green-500" />;
    }
    
    return <User size={16} className="text-gray-500" />;
  };

  const getMessageStatusIcon = (status?: string) => {
    switch (status) {
      case 'sending':
        return <Clock size={12} className="text-gray-400" />;
      case 'sent':
        return <CheckCheck size={12} className="text-gray-400" />;
      case 'delivered':
        return <CheckCheck size={12} className="text-blue-500" />;
      case 'read':
        return <CheckCheck size={12} className="text-green-500" />;
      default:
        return null;
    }
  };

  const formatTime = (timestamp: Date) => {
    return timestamp.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <Card className={`h-96 flex flex-col ${className}`}>
      {/* Chat Header */}
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-2">
              {agentInfo ? (
                <>
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-green-100 text-green-800">
                      {agentInfo.name.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <CardTitle className="text-sm">{agentInfo.name}</CardTitle>
                    <Badge variant="secondary" className="text-xs bg-green-100 text-green-800">
                      Human Agent
                    </Badge>
                  </div>
                </>
              ) : (
                <>
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-primary-100 text-primary-600">
                      <Bot size={16} />
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <CardTitle className="text-sm">AI Assistant</CardTitle>
                    <Badge variant="secondary" className="text-xs">
                      Online
                    </Badge>
                  </div>
                </>
              )}
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Badge 
              variant={connectionStatus === 'connected' ? 'default' : 'destructive'}
              className="text-xs"
            >
              {connectionStatus === 'connected' ? 'Connected' : 
               connectionStatus === 'connecting' ? 'Connecting...' : 'Disconnected'}
            </Badge>
            
            {!agentInfo && (
              <Button
                variant="outline"
                size="sm"
                onClick={requestHumanAgent}
                className="text-xs"
              >
                Human Agent
              </Button>
            )}
          </div>
        </div>
      </CardHeader>

      {/* Chat Messages */}
      <CardContent className="flex-1 flex flex-col p-0">
        <ScrollArea className="flex-1 px-4">
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${
                  message.isFromPlatform || message.type === 'system' 
                    ? 'justify-start' 
                    : 'justify-end'
                }`}
              >
                <div className={`max-w-[80%] ${
                  message.type === 'system' 
                    ? 'w-full' 
                    : message.isFromPlatform 
                      ? 'mr-auto' 
                      : 'ml-auto'
                }`}>
                  <div className={`rounded-lg p-3 ${
                    message.type === 'system' 
                      ? 'bg-blue-50 text-blue-800 text-center text-sm' 
                      : message.type === 'handoff'
                        ? 'bg-yellow-50 text-yellow-800 text-center text-sm'
                        : message.isFromPlatform
                          ? 'bg-gray-100 text-gray-800'
                          : 'bg-accent-coral text-white'
                  }`}>
                    {message.type !== 'system' && message.type !== 'handoff' && (
                      <div className="flex items-center space-x-2 mb-1">
                        {getMessageIcon(message)}
                        <span className="text-xs opacity-75">
                          {message.senderId === 'ai-assistant' 
                            ? 'AI Assistant' 
                            : agentInfo?.name || 'You'}
                        </span>
                      </div>
                    )}
                    
                    <p className="text-sm">{message.content}</p>
                    
                    {message.type !== 'system' && message.type !== 'handoff' && (
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-xs opacity-60">
                          {formatTime(message.timestamp)}
                        </span>
                        {!message.isFromPlatform && (
                          <div className="flex items-center space-x-1">
                            {getMessageStatusIcon(message.status)}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}

            {/* Typing indicator */}
            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-gray-100 rounded-lg p-3 max-w-[80%]">
                  <div className="flex items-center space-x-2">
                    {getMessageIcon({ senderId: 'agent', isFromPlatform: true } as Message)}
                    <span className="text-xs text-gray-600">
                      {agentInfo?.name || 'AI Assistant'} is typing...
                    </span>
                    <div className="flex space-x-1">
                      <div className="w-1 h-1 bg-gray-400 rounded-full animate-bounce"></div>
                      <div className="w-1 h-1 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-1 h-1 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>

        {/* Chat Input */}
        <div className="border-t p-4">
          <div className="flex items-center space-x-2">
            <div className="flex-1 relative">
              <Input
                ref={inputRef}
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder={
                  connectionStatus === 'connected' 
                    ? "Type your message..." 
                    : "Connecting to support..."
                }
                disabled={connectionStatus !== 'connected'}
                className="pr-10"
              />
              <Button
                variant="ghost"
                size="sm"
                className="absolute right-1 top-1/2 transform -translate-y-1/2 p-1 h-8 w-8"
                disabled
              >
                <Paperclip size={16} />
              </Button>
            </div>
            
            <Button
              onClick={sendMessage}
              disabled={!newMessage.trim() || connectionStatus !== 'connected'}
              className="bg-accent-coral hover:bg-red-600"
              size="sm"
            >
              <Send size={16} />
            </Button>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center justify-between mt-3 pt-3 border-t">
            <div className="flex space-x-2">
              <Button variant="outline" size="sm" disabled>
                <Phone size={14} className="mr-1" />
                Call
              </Button>
              <Button variant="outline" size="sm" disabled>
                <Video size={14} className="mr-1" />
                Video
              </Button>
            </div>
            
            <div className="text-xs text-gray-500">
              {isConnected ? 'Online' : 'Connecting...'}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
