import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Brain, Home, Mic, Camera, Headset, Play, Star } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  const handleWatchDemo = () => {
    // Implement demo video modal or redirect
    console.log("Opening demo video");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <header className="bg-white shadow-lg sticky top-0 z-50">
        <nav className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="text-2xl font-bold text-primary-500">
                <Brain className="inline mr-2 text-accent-coral" size={28} />
                AImpress Living
              </div>
            </div>
            
            <div className="hidden md:flex items-center space-x-8">
              <a href="#products" className="text-gray-700 hover:text-primary-500 transition-colors">Products</a>
              <a href="#features" className="text-gray-700 hover:text-primary-500 transition-colors">AI Features</a>
              <a href="#about" className="text-gray-700 hover:text-primary-500 transition-colors">About</a>
              <a href="#support" className="text-gray-700 hover:text-primary-500 transition-colors">Support</a>
            </div>

            <div className="flex items-center space-x-4">
              <Button onClick={handleLogin} className="bg-accent-coral hover:bg-red-600">
                Sign In
              </Button>
            </div>
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="relative gradient-primary text-white py-20">
        <div className="absolute inset-0 bg-black opacity-40"></div>
        <div 
          className="absolute inset-0" 
          style={{
            backgroundImage: 'url("https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080")',
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
        ></div>
        <div className="relative container mx-auto px-6 text-center">
          <h1 className="text-5xl md:text-7xl font-bold mb-6">
            The Future of
            <span className="text-accent-coral"> Smart Living</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
            Experience AI-powered furniture that responds to your voice, adapts to your needs, and transforms your living space into an intelligent environment.
          </p>
          
          <div className="flex flex-col md:flex-row gap-4 justify-center items-center mb-12">
            <Button 
              size="lg" 
              className="bg-accent-coral hover:bg-red-600 text-lg px-8 py-4"
              onClick={() => document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' })}
            >
              Explore Products
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-white text-white hover:bg-white hover:text-primary-500 text-lg px-8 py-4"
              onClick={handleWatchDemo}
            >
              <Play className="mr-2" size={20} />
              Watch Demo
            </Button>
          </div>

          {/* Voice Command Demo */}
          <Card className="bg-white bg-opacity-10 backdrop-blur-md max-w-md mx-auto">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold mb-4">Try Voice Command</h3>
              <div className="flex items-center space-x-4">
                <Button 
                  className="bg-accent-coral hover:bg-red-600 p-3 rounded-full voice-pulse"
                  onClick={() => console.log("Voice demo started")}
                >
                  <Mic className="text-white" size={20} />
                </Button>
                <div className="text-left">
                  <p className="text-sm opacity-80">Say: "Hey table, come closer"</p>
                  <p className="text-xs opacity-60">Demo simulation ready</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Product Categories Preview */}
      <section id="products" className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Smart Furniture Categories</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Discover our AI-powered furniture collection designed to revolutionize your living experience
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Sample Product Cards */}
            <Card className="card-hover">
              <div className="relative">
                <img 
                  src="https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                  alt="AI Smart Table" 
                  className="w-full h-48 object-cover rounded-t-lg"
                />
                <Badge className="absolute top-4 left-4 bg-accent-coral">AI Enabled</Badge>
              </div>
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-2">SmartTable Pro X1</h3>
                <p className="text-gray-600 mb-4">Voice-controlled adjustable table with built-in AI assistant</p>
                
                <div className="flex items-center mb-4">
                  <div className="flex text-yellow-500">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} size={16} fill="currentColor" />
                    ))}
                  </div>
                  <span className="text-gray-600 ml-2 text-sm">4.9 (127 reviews)</span>
                </div>

                <div className="flex items-center justify-between mb-4">
                  <div>
                    <span className="text-2xl font-bold text-primary-500">$1,299</span>
                    <span className="text-gray-500 line-through ml-2">$1,599</span>
                  </div>
                  <Badge variant="secondary" className="text-green-600">19% OFF</Badge>
                </div>

                <Button 
                  className="w-full bg-accent-coral hover:bg-red-600"
                  onClick={handleLogin}
                >
                  View Details
                </Button>
              </CardContent>
            </Card>

            <Card className="card-hover">
              <div className="relative">
                <img 
                  src="https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                  alt="AI Smart Chair" 
                  className="w-full h-48 object-cover rounded-t-lg"
                />
                <Badge className="absolute top-4 left-4 bg-blue-500">Best Seller</Badge>
              </div>
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-2">ErgoSmart Chair Elite</h3>
                <p className="text-gray-600 mb-4">AI-powered ergonomic chair with posture correction</p>
                
                <div className="flex items-center mb-4">
                  <div className="flex text-yellow-500">
                    {[...Array(4)].map((_, i) => (
                      <Star key={i} size={16} fill="currentColor" />
                    ))}
                    <Star size={16} fill="currentColor" className="opacity-50" />
                  </div>
                  <span className="text-gray-600 ml-2 text-sm">4.7 (89 reviews)</span>
                </div>

                <div className="flex items-center justify-between mb-4">
                  <div>
                    <span className="text-2xl font-bold text-primary-500">$899</span>
                    <span className="text-gray-500 line-through ml-2">$1,199</span>
                  </div>
                  <Badge variant="secondary" className="text-green-600">25% OFF</Badge>
                </div>

                <Button 
                  className="w-full bg-accent-coral hover:bg-red-600"
                  onClick={handleLogin}
                >
                  View Details
                </Button>
              </CardContent>
            </Card>

            <Card className="card-hover">
              <div className="relative">
                <img 
                  src="https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                  alt="AI Smart Storage" 
                  className="w-full h-48 object-cover rounded-t-lg"
                />
                <Badge className="absolute top-4 left-4 bg-purple-500">New</Badge>
              </div>
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-2">IntelliStore Cabinet</h3>
                <p className="text-gray-600 mb-4">Self-organizing storage with AI inventory management</p>
                
                <div className="flex items-center mb-4">
                  <div className="flex text-yellow-500">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} size={16} fill="currentColor" />
                    ))}
                  </div>
                  <span className="text-gray-600 ml-2 text-sm">5.0 (23 reviews)</span>
                </div>

                <div className="flex items-center justify-between mb-4">
                  <div>
                    <span className="text-2xl font-bold text-primary-500">$2,199</span>
                    <span className="text-gray-500 line-through ml-2">$2,599</span>
                  </div>
                  <Badge variant="secondary" className="text-green-600">15% OFF</Badge>
                </div>

                <Button 
                  className="w-full bg-accent-coral hover:bg-red-600"
                  onClick={handleLogin}
                >
                  View Details
                </Button>
              </CardContent>
            </Card>

            <Card className="card-hover">
              <div className="relative">
                <img 
                  src="https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                  alt="AI Smart Lamp" 
                  className="w-full h-48 object-cover rounded-t-lg"
                />
                <Badge className="absolute top-4 left-4 bg-yellow-500">Popular</Badge>
              </div>
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-2">LuminAI Smart Lamp</h3>
                <p className="text-gray-600 mb-4">Mood-responsive lighting with circadian rhythm sync</p>
                
                <div className="flex items-center mb-4">
                  <div className="flex text-yellow-500">
                    {[...Array(4)].map((_, i) => (
                      <Star key={i} size={16} fill="currentColor" />
                    ))}
                    <Star size={16} fill="currentColor" className="opacity-50" />
                  </div>
                  <span className="text-gray-600 ml-2 text-sm">4.8 (156 reviews)</span>
                </div>

                <div className="flex items-center justify-between mb-4">
                  <div>
                    <span className="text-2xl font-bold text-primary-500">$449</span>
                    <span className="text-gray-500 line-through ml-2">$599</span>
                  </div>
                  <Badge variant="secondary" className="text-green-600">25% OFF</Badge>
                </div>

                <Button 
                  className="w-full bg-accent-coral hover:bg-red-600"
                  onClick={handleLogin}
                >
                  View Details
                </Button>
              </CardContent>
            </Card>
          </div>

          <div className="text-center mt-12">
            <Button 
              size="lg" 
              className="bg-primary-500 hover:bg-primary-600"
              onClick={handleLogin}
            >
              Sign In to Explore All Products
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-16 bg-gradient-to-br from-gray-100 to-gray-200">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Advanced AI Features</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Experience cutting-edge technology that makes our furniture truly intelligent
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="bg-white bg-opacity-90 backdrop-blur-md card-hover">
              <CardContent className="p-8">
                <div className="bg-accent-coral p-4 rounded-full w-16 h-16 flex items-center justify-center mb-6">
                  <Home className="text-white" size={24} />
                </div>
                <h3 className="text-xl font-bold mb-4">Smart Home Integration</h3>
                <p className="text-gray-600 mb-6">
                  Seamlessly connect with Alexa, Google Home, Apple HomeKit, and other smart home ecosystems.
                </p>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li>✓ Alexa & Google Assistant</li>
                  <li>✓ Apple HomeKit Compatible</li>
                  <li>✓ Samsung SmartThings</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-white bg-opacity-90 backdrop-blur-md card-hover">
              <CardContent className="p-8">
                <div className="bg-blue-500 p-4 rounded-full w-16 h-16 flex items-center justify-center mb-6">
                  <Brain className="text-white" size={24} />
                </div>
                <h3 className="text-xl font-bold mb-4">Machine Learning Adaptation</h3>
                <p className="text-gray-600 mb-6">
                  AI learns your preferences and daily routines to proactively adjust furniture settings.
                </p>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li>✓ Behavioral Pattern Learning</li>
                  <li>✓ Predictive Adjustments</li>
                  <li>✓ Personal Preferences</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-white bg-opacity-90 backdrop-blur-md card-hover">
              <CardContent className="p-8">
                <div className="bg-green-500 p-4 rounded-full w-16 h-16 flex items-center justify-center mb-6">
                  <Mic className="text-white" size={24} />
                </div>
                <h3 className="text-xl font-bold mb-4">Advanced Voice Recognition</h3>
                <p className="text-gray-600 mb-6">
                  Multi-language support with voice print recognition for personalized responses.
                </p>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li>✓ 50+ Languages Supported</li>
                  <li>✓ Voice Print Recognition</li>
                  <li>✓ Natural Language Processing</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-gray-800 mb-4">Meet the Founder</h2>
              <p className="text-xl text-gray-600">
                Discover the vision behind AImpress Living
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-6">
                <div>
                  <h3 className="text-2xl font-bold text-gray-800 mb-4">Abhishek Biradar</h3>
                  <p className="text-lg text-accent-coral font-semibold mb-4">Founder & CEO, AImpress Living</p>
                  <p className="text-gray-600 leading-relaxed mb-6">
                    With over a decade of experience in AI technology and furniture design, Abhishek envisioned a world where furniture adapts to human needs rather than the other way around. His passion for creating intelligent living spaces has led to revolutionary breakthroughs in voice-controlled furniture and smart home integration.
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="text-2xl font-bold text-primary-500 mb-2">15+</div>
                    <div className="text-sm text-gray-600">Years in AI Technology</div>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="text-2xl font-bold text-primary-500 mb-2">50+</div>
                    <div className="text-sm text-gray-600">Patents Filed</div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="text-lg font-semibold text-gray-800">Vision & Mission</h4>
                  <p className="text-gray-600">
                    "Our mission is to transform every living space into an intelligent environment that anticipates and responds to human needs. We believe the future of furniture lies in seamless integration of AI technology with timeless design principles."
                  </p>
                </div>
              </div>

              <div>
                <div className="relative">
                  <img 
                    src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800" 
                    alt="Abhishek Biradar - Founder of AImpress Living" 
                    className="w-full rounded-2xl shadow-lg"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 gradient-primary text-white">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-4xl font-bold mb-4">Ready to Transform Your Living Space?</h2>
          <p className="text-xl text-primary-100 mb-8 max-w-2xl mx-auto">
            Join thousands of satisfied customers who have already revolutionized their homes with AI-powered furniture.
          </p>
          
          <div className="flex flex-col md:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-accent-coral hover:bg-red-600 text-lg px-8 py-4"
              onClick={handleLogin}
            >
              Get Started Today
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-white text-white hover:bg-white hover:text-primary-500 text-lg px-8 py-4"
              onClick={() => document.getElementById('support')?.scrollIntoView({ behavior: 'smooth' })}
            >
              Learn More
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-primary-500 text-white py-12">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="text-2xl font-bold mb-4">
                <Brain className="inline mr-2 text-accent-coral" size={28} />
                AImpress Living
              </div>
              <p className="text-primary-100 mb-4">
                Revolutionizing living spaces with AI-powered smart furniture that adapts to your lifestyle.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Products</h3>
              <ul className="space-y-2 text-primary-100">
                <li>Smart Tables</li>
                <li>Smart Chairs</li>
                <li>Smart Storage</li>
                <li>Smart Lighting</li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-primary-100">
                <li>Help Center</li>
                <li>Installation Guide</li>
                <li>Warranty</li>
                <li>Contact Us</li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-primary-100">
                <li>About Us</li>
                <li>Careers</li>
                <li>Press</li>
                <li>Privacy Policy</li>
              </ul>
            </div>
          </div>

          <div className="border-t border-primary-600 mt-8 pt-8 text-center text-primary-100">
            <p>&copy; 2024 AImpress Living. All rights reserved. Founded by Abhishek Biradar.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
