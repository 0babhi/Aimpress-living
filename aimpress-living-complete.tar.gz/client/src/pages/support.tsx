import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import Navigation from "@/components/navigation";
import ChatSupport from "@/components/chat-support";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  MessageCircle,
  Phone,
  Mail,
  Video,
  Clock,
  TrendingUp,
  CheckCircle,
  HelpCircle,
  Book,
  Settings,
  Shield,
  FileText,
  Headphones,
  Bot,
  User,
  Send
} from "lucide-react";

export default function Support() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [showChat, setShowChat] = useState(false);
  const [newTicket, setNewTicket] = useState({
    subject: '',
    description: '',
    priority: 'medium',
    orderId: '',
  });

  // Fetch support tickets
  const { data: tickets = [], isLoading: ticketsLoading } = useQuery({
    queryKey: ['/api/support/tickets'],
    enabled: isAuthenticated,
  });

  // Create support ticket mutation
  const createTicketMutation = useMutation({
    mutationFn: async (ticketData: any) => {
      const response = await apiRequest('POST', '/api/support/tickets', ticketData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Support Ticket Created",
        description: "Your support request has been submitted. We'll get back to you soon!",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/support/tickets'] });
      setNewTicket({
        subject: '',
        description: '',
        priority: 'medium',
        orderId: '',
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Failed to create ticket",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [isAuthenticated, isLoading, toast]);

  const handleCreateTicket = (e: React.FormEvent) => {
    e.preventDefault();
    createTicketMutation.mutate(newTicket);
  };

  const handleStartLiveChat = () => {
    setShowChat(true);
  };

  const handleScheduleVideoCall = () => {
    toast({
      title: "Video Call Scheduled",
      description: "A support representative will contact you within 24 hours.",
    });
  };

  const handleRequestRemoteAssistance = () => {
    toast({
      title: "Remote Assistance Requested",
      description: "Please wait while we prepare a secure connection to your device.",
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <div className="container mx-auto px-6 py-8">
          <div className="spinner mx-auto"></div>
        </div>
      </div>
    );
  }

  const getTicketStatusColor = (status: string) => {
    switch (status) {
      case 'open': return 'bg-red-100 text-red-800';
      case 'in_progress': return 'bg-yellow-100 text-yellow-800';
      case 'resolved': return 'bg-green-100 text-green-800';
      case 'closed': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-100 text-red-800';
      case 'high': return 'bg-orange-100 text-orange-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const knowledgeBaseItems = [
    {
      icon: <HelpCircle className="text-accent-coral" size={20} />,
      title: "Voice Command Guide",
      description: "Complete list of voice commands for all AI furniture",
      category: "Getting Started"
    },
    {
      icon: <Settings className="text-blue-500" size={20} />,
      title: "Setup & Installation",
      description: "Step-by-step setup instructions for smart furniture",
      category: "Installation"
    },
    {
      icon: <FileText className="text-green-500" size={20} />,
      title: "Troubleshooting",
      description: "Common issues and solutions for AI furniture",
      category: "Troubleshooting"
    },
    {
      icon: <Shield className="text-purple-500" size={20} />,
      title: "Warranty & Returns",
      description: "Warranty information and return policies",
      category: "Warranty"
    },
    {
      icon: <Bot className="text-indigo-500" size={20} />,
      title: "AI Features Guide",
      description: "Understanding and using advanced AI capabilities",
      category: "Features"
    },
    {
      icon: <Headphones className="text-pink-500" size={20} />,
      title: "Smart Home Integration",
      description: "Connecting with Alexa, Google, and other platforms",
      category: "Integration"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      {/* Header */}
      <section className="bg-white border-b">
        <div className="container mx-auto px-6 py-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Customer Support</h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Get help with your AI furniture through our comprehensive support system
            </p>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Support Options */}
          <div className="lg:col-span-2 space-y-6">
            <Tabs defaultValue="help" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="help">Get Help</TabsTrigger>
                <TabsTrigger value="tickets">My Tickets</TabsTrigger>
                <TabsTrigger value="knowledge">Knowledge Base</TabsTrigger>
                <TabsTrigger value="chat">AI Chat</TabsTrigger>
              </TabsList>

              <TabsContent value="help" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Create Support Ticket</CardTitle>
                    <p className="text-gray-600">
                      Describe your issue and our support team will help you resolve it.
                    </p>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleCreateTicket} className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="subject">Subject</Label>
                          <Input
                            id="subject"
                            value={newTicket.subject}
                            onChange={(e) => setNewTicket(prev => ({ ...prev, subject: e.target.value }))}
                            placeholder="Brief description of your issue"
                            required
                          />
                        </div>

                        <div>
                          <Label htmlFor="priority">Priority</Label>
                          <Select value={newTicket.priority} onValueChange={(value) => 
                            setNewTicket(prev => ({ ...prev, priority: value }))
                          }>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="low">Low</SelectItem>
                              <SelectItem value="medium">Medium</SelectItem>
                              <SelectItem value="high">High</SelectItem>
                              <SelectItem value="urgent">Urgent</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="orderId">Related Order (Optional)</Label>
                        <Input
                          id="orderId"
                          value={newTicket.orderId}
                          onChange={(e) => setNewTicket(prev => ({ ...prev, orderId: e.target.value }))}
                          placeholder="Order ID if this relates to a specific order"
                        />
                      </div>

                      <div>
                        <Label htmlFor="description">Description</Label>
                        <Textarea
                          id="description"
                          value={newTicket.description}
                          onChange={(e) => setNewTicket(prev => ({ ...prev, description: e.target.value }))}
                          placeholder="Please provide detailed information about your issue..."
                          rows={5}
                          required
                        />
                      </div>

                      <Button 
                        type="submit" 
                        className="bg-accent-coral hover:bg-red-600"
                        disabled={createTicketMutation.isPending}
                      >
                        {createTicketMutation.isPending ? 'Creating...' : 'Create Ticket'}
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="tickets" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Your Support Tickets</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {ticketsLoading ? (
                      <div className="flex items-center justify-center py-8">
                        <div className="spinner"></div>
                      </div>
                    ) : tickets.length === 0 ? (
                      <div className="text-center py-8">
                        <HelpCircle className="mx-auto mb-4 text-gray-400" size={48} />
                        <h3 className="text-xl font-semibold text-gray-600 mb-2">No support tickets</h3>
                        <p className="text-gray-500">Create a ticket above if you need help.</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {tickets.map((ticket: any) => (
                          <div key={ticket.id} className="border rounded-lg p-4">
                            <div className="flex items-start justify-between mb-3">
                              <div>
                                <h4 className="font-semibold">{ticket.subject}</h4>
                                <p className="text-sm text-gray-600">
                                  Created: {new Date(ticket.createdAt).toLocaleDateString()}
                                </p>
                              </div>
                              <div className="flex space-x-2">
                                <Badge className={getTicketStatusColor(ticket.status)}>
                                  {ticket.status.charAt(0).toUpperCase() + ticket.status.slice(1)}
                                </Badge>
                                <Badge className={getPriorityColor(ticket.priority)}>
                                  {ticket.priority.charAt(0).toUpperCase() + ticket.priority.slice(1)}
                                </Badge>
                              </div>
                            </div>
                            <p className="text-sm text-gray-700 mb-3">{ticket.description}</p>
                            {ticket.resolution && (
                              <div className="bg-green-50 p-3 rounded-lg">
                                <p className="text-sm text-green-800">
                                  <strong>Resolution:</strong> {ticket.resolution}
                                </p>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="knowledge" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Knowledge Base</CardTitle>
                    <p className="text-gray-600">
                      Find answers to common questions and learn about AI furniture features.
                    </p>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {knowledgeBaseItems.map((item, index) => (
                        <div 
                          key={index}
                          className="flex items-start p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer"
                        >
                          <div className="mr-4 mt-1">
                            {item.icon}
                          </div>
                          <div>
                            <h4 className="font-semibold text-gray-800 mb-1">{item.title}</h4>
                            <p className="text-sm text-gray-600 mb-2">{item.description}</p>
                            <Badge variant="outline" className="text-xs">
                              {item.category}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="chat" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Bot className="mr-2 text-primary-500" size={20} />
                      AI Support Assistant
                    </CardTitle>
                    <p className="text-gray-600">
                      Get instant help from our AI assistant or chat with a human agent.
                    </p>
                  </CardHeader>
                  <CardContent>
                    {showChat ? (
                      <ChatSupport />
                    ) : (
                      <div className="text-center py-8">
                        <Bot className="mx-auto mb-4 text-primary-500" size={64} />
                        <h3 className="text-xl font-semibold mb-2">Start Conversation</h3>
                        <p className="text-gray-600 mb-6">
                          Our AI assistant is available 24/7 to help with your questions
                        </p>
                        <Button 
                          onClick={handleStartLiveChat}
                          className="bg-primary-500 hover:bg-primary-600"
                        >
                          <MessageCircle className="mr-2" size={16} />
                          Start Chat
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Contact Information & Stats */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Contact Options</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div 
                  className="flex items-center p-4 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50"
                  onClick={handleStartLiveChat}
                >
                  <MessageCircle className="text-accent-coral mr-4" size={20} />
                  <div>
                    <h4 className="font-semibold text-gray-800">Live Chat</h4>
                    <p className="text-sm text-gray-600">Available 24/7</p>
                    <Button variant="link" className="text-accent-coral p-0 h-auto font-medium">
                      Start Chat
                    </Button>
                  </div>
                </div>

                <div className="flex items-center p-4 border border-gray-200 rounded-lg">
                  <Phone className="text-blue-500 mr-4" size={20} />
                  <div>
                    <h4 className="font-semibold text-gray-800">Phone Support</h4>
                    <p className="text-sm text-gray-600">Mon-Fri 9AM-6PM</p>
                    <p className="text-accent-coral font-medium">1-800-AI-LIVING</p>
                  </div>
                </div>

                <div className="flex items-center p-4 border border-gray-200 rounded-lg">
                  <Mail className="text-green-500 mr-4" size={20} />
                  <div>
                    <h4 className="font-semibold text-gray-800">Email Support</h4>
                    <p className="text-sm text-gray-600">Response within 24 hours</p>
                    <p className="text-accent-coral font-medium">support@aimpressliving.com</p>
                  </div>
                </div>

                <div 
                  className="flex items-center p-4 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50"
                  onClick={handleScheduleVideoCall}
                >
                  <Video className="text-purple-500 mr-4" size={20} />
                  <div>
                    <h4 className="font-semibold text-gray-800">Video Support</h4>
                    <p className="text-sm text-gray-600">Remote assistance available</p>
                    <Button variant="link" className="text-accent-coral p-0 h-auto font-medium">
                      Schedule Call
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Support Performance Stats */}
            <Card>
              <CardHeader>
                <CardTitle>Support Performance</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Average Response Time</span>
                  <span className="font-semibold text-primary-500">&lt; 2 minutes</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Customer Satisfaction</span>
                  <span className="font-semibold text-green-500">98.5%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">First Contact Resolution</span>
                  <span className="font-semibold text-blue-500">94%</span>
                </div>
              </CardContent>
            </Card>

            {/* Remote Assistance */}
            <Card className="gradient-primary text-white">
              <CardHeader>
                <CardTitle>Remote Assistance</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-primary-100 mb-4">
                  Our technicians can remotely access your smart furniture to diagnose and fix issues instantly.
                </p>
                <Button 
                  className="bg-white text-primary-500 hover:bg-gray-100"
                  onClick={handleRequestRemoteAssistance}
                >
                  <Settings className="mr-2" size={16} />
                  Request Remote Help
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
