import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Navigation from "@/components/navigation";
import ProductCard from "@/components/product-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Grid, List, Search, Filter, SlidersHorizontal } from "lucide-react";

export default function Products() {
  const [filters, setFilters] = useState({
    category: '',
    priceMin: '',
    priceMax: '',
    search: '',
    aiFeatures: [] as string[],
  });
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const { data: products = [], isLoading } = useQuery({
    queryKey: ['/api/products', filters],
    queryFn: async () => {
      const params = new URLSearchParams();
      
      if (filters.category) params.append('category', filters.category);
      if (filters.priceMin) params.append('priceMin', filters.priceMin);
      if (filters.priceMax) params.append('priceMax', filters.priceMax);
      if (filters.search) params.append('search', filters.search);
      
      filters.aiFeatures.forEach(feature => {
        params.append('aiFeatures', feature);
      });

      const response = await fetch(`/api/products?${params}`);
      if (!response.ok) throw new Error('Failed to fetch products');
      return response.json();
    },
  });

  const categories = [
    { value: 'tables', label: 'Tables' },
    { value: 'chairs', label: 'Chairs' },
    { value: 'storage', label: 'Storage' },
    { value: 'lighting', label: 'Lighting' },
  ];

  const priceRanges = [
    { value: '500-1000', label: '$500 - $1,000' },
    { value: '1000-2500', label: '$1,000 - $2,500' },
    { value: '2500-5000', label: '$2,500 - $5,000' },
    { value: '5000+', label: '$5,000+' },
  ];

  const aiFeatureOptions = [
    'voice_control',
    'movement',
    'smart_sensing',
    'biometric',
    'predictive',
  ];

  const handlePriceRangeChange = (value: string) => {
    if (value === '5000+') {
      setFilters(prev => ({ ...prev, priceMin: '5000', priceMax: '' }));
    } else {
      const [min, max] = value.split('-');
      setFilters(prev => ({ ...prev, priceMin: min, priceMax: max }));
    }
  };

  const toggleAIFeature = (feature: string) => {
    setFilters(prev => ({
      ...prev,
      aiFeatures: prev.aiFeatures.includes(feature)
        ? prev.aiFeatures.filter(f => f !== feature)
        : [...prev.aiFeatures, feature]
    }));
  };

  const clearFilters = () => {
    setFilters({
      category: '',
      priceMin: '',
      priceMax: '',
      search: '',
      aiFeatures: [],
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      {/* Header */}
      <section className="bg-white py-12 border-b">
        <div className="container mx-auto px-6">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">AI-Powered Furniture</h1>
          <p className="text-xl text-gray-600 max-w-2xl">
            Discover our complete collection of intelligent furniture that adapts to your lifestyle
          </p>
        </div>
      </section>

      <div className="container mx-auto px-6 py-8">
        {/* Filters */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="flex flex-wrap gap-4 items-center justify-between mb-4">
              <div className="flex flex-wrap gap-4 flex-1">
                {/* Search */}
                <div className="relative min-w-[200px]">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
                  <Input
                    placeholder="Search products..."
                    className="pl-10"
                    value={filters.search}
                    onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
                  />
                </div>

                {/* Category */}
                <Select value={filters.category} onValueChange={(value) => setFilters(prev => ({ ...prev, category: value }))}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="All Categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All Categories</SelectItem>
                    {categories.map((category) => (
                      <SelectItem key={category.value} value={category.value}>
                        {category.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {/* Price Range */}
                <Select onValueChange={handlePriceRangeChange}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Price Range" />
                  </SelectTrigger>
                  <SelectContent>
                    {priceRanges.map((range) => (
                      <SelectItem key={range.value} value={range.value}>
                        {range.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {/* Clear Filters */}
                <Button variant="outline" onClick={clearFilters}>
                  <Filter className="mr-2" size={16} />
                  Clear Filters
                </Button>
              </div>

              {/* View Toggle */}
              <div className="flex gap-2">
                <Button
                  variant={viewMode === 'grid' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setViewMode('grid')}
                >
                  <Grid className="mr-2" size={16} />
                  Grid
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setViewMode('list')}
                >
                  <List className="mr-2" size={16} />
                  List
                </Button>
              </div>
            </div>

            {/* AI Features Filter */}
            <div>
              <p className="text-sm font-medium text-gray-700 mb-3">AI Features:</p>
              <div className="flex flex-wrap gap-2">
                {aiFeatureOptions.map((feature) => (
                  <Badge
                    key={feature}
                    variant={filters.aiFeatures.includes(feature) ? "default" : "outline"}
                    className="cursor-pointer"
                    onClick={() => toggleAIFeature(feature)}
                  >
                    {feature.replace('_', ' ').charAt(0).toUpperCase() + feature.slice(1)}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Active Filters */}
            {(filters.category || filters.search || filters.priceMin || filters.aiFeatures.length > 0) && (
              <div className="mt-4 pt-4 border-t">
                <p className="text-sm text-gray-600 mb-2">Active filters:</p>
                <div className="flex flex-wrap gap-2">
                  {filters.category && (
                    <Badge variant="secondary">
                      Category: {categories.find(c => c.value === filters.category)?.label}
                    </Badge>
                  )}
                  {filters.search && (
                    <Badge variant="secondary">
                      Search: "{filters.search}"
                    </Badge>
                  )}
                  {filters.priceMin && (
                    <Badge variant="secondary">
                      Price: ${filters.priceMin}{filters.priceMax ? ` - $${filters.priceMax}` : '+'}
                    </Badge>
                  )}
                  {filters.aiFeatures.map((feature) => (
                    <Badge key={feature} variant="secondary">
                      AI: {feature.replace('_', ' ')}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Results */}
        <div className="flex items-center justify-between mb-6">
          <p className="text-gray-600">
            {isLoading ? 'Loading...' : `${products.length} products found`}
          </p>
          
          <Select defaultValue="newest">
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Newest First</SelectItem>
              <SelectItem value="price-low">Price: Low to High</SelectItem>
              <SelectItem value="price-high">Price: High to Low</SelectItem>
              <SelectItem value="rating">Highest Rated</SelectItem>
              <SelectItem value="popular">Most Popular</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Products Grid/List */}
        {isLoading ? (
          <div className={`grid gap-6 ${viewMode === 'grid' ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' : 'grid-cols-1'}`}>
            {[...Array(8)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <div className="bg-gray-300 h-48 rounded-t-lg"></div>
                <CardContent className="p-6">
                  <div className="h-4 bg-gray-300 rounded mb-2"></div>
                  <div className="h-3 bg-gray-300 rounded mb-4"></div>
                  <div className="h-8 bg-gray-300 rounded"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : products.length === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <SlidersHorizontal className="mx-auto mb-4 text-gray-400" size={48} />
              <h3 className="text-xl font-semibold text-gray-600 mb-2">No products found</h3>
              <p className="text-gray-500">Try adjusting your filters to see more results</p>
              <Button className="mt-4" onClick={clearFilters}>
                Clear All Filters
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className={`grid gap-6 ${viewMode === 'grid' ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' : 'grid-cols-1'}`}>
            {products.map((product) => (
              <ProductCard 
                key={product.id} 
                product={product} 
                viewMode={viewMode}
              />
            ))}
          </div>
        )}

        {/* Load More */}
        {products.length > 0 && products.length % 12 === 0 && (
          <div className="text-center mt-12">
            <Button size="lg" variant="outline">
              Load More Products
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
