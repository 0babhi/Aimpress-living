import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Eye,
  MoreVertical,
  CheckCircle,
  XCircle,
  MessageSquare,
  Calculator,
  Truck,
  Package,
  Star,
  Clock,
  DollarSign,
  FileText,
  Phone,
  MapPin
} from "lucide-react";
import type { Order } from "@shared/schema";

interface OrderTableProps {
  orders: Order[];
  isVendor?: boolean;
  onUpdateOrder?: (orderId: string, status: string, updates?: any) => void;
  className?: string;
}

export default function OrderTable({ 
  orders, 
  isVendor = false, 
  onUpdateOrder,
  className = "" 
}: OrderTableProps) {
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [showPricingModal, setShowPricingModal] = useState(false);
  const [pricing, setPricing] = useState({
    materials: '',
    labor: '',
    aiComponents: '',
    shipping: '',
    total: '',
    notes: '',
    deadline: '',
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'delivered': return 'bg-green-100 text-green-800';
      case 'shipped': return 'bg-blue-100 text-blue-800';
      case 'in_production': return 'bg-yellow-100 text-yellow-800';
      case 'accepted': return 'bg-purple-100 text-purple-800';
      case 'pending': return 'bg-gray-100 text-gray-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = (customizations: any) => {
    // Determine priority based on customizations complexity
    if (!customizations || typeof customizations !== 'object') return 'bg-green-100 text-green-800';
    
    const hasComplexCustomizations = Object.keys(customizations).length > 3;
    return hasComplexCustomizations ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800';
  };

  const formatPrice = (price: string | number | undefined | null) => {
    if (!price) return '$0.00';
    const numPrice = typeof price === 'string' ? parseFloat(price) : price;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(numPrice);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const handleStatusUpdate = (orderId: string, newStatus: string) => {
    if (onUpdateOrder) {
      onUpdateOrder(orderId, newStatus);
    }
  };

  const handleAcceptOrder = (order: Order) => {
    setSelectedOrder(order);
    setShowPricingModal(true);
  };

  const handleSubmitPricing = () => {
    if (!selectedOrder || !onUpdateOrder) return;

    const totalCost = parseFloat(pricing.materials || '0') + 
                     parseFloat(pricing.labor || '0') + 
                     parseFloat(pricing.aiComponents || '0') + 
                     parseFloat(pricing.shipping || '0');

    onUpdateOrder(selectedOrder.id, 'accepted', {
      finalCost: totalCost.toString(),
      deadline: pricing.deadline,
      notes: pricing.notes,
    });

    setShowPricingModal(false);
    setPricing({
      materials: '',
      labor: '',
      aiComponents: '',
      shipping: '',
      total: '',
      notes: '',
      deadline: '',
    });
  };

  const getCustomizationsList = (customizations: any) => {
    if (!customizations || typeof customizations !== 'object') {
      return ['Standard configuration'];
    }

    const items = [];
    if (customizations.material) items.push(`Material: ${customizations.material}`);
    if (customizations.color) items.push(`Color: ${customizations.color}`);
    if (customizations.dimensions) items.push(`Dimensions: ${customizations.dimensions}`);
    if (customizations.voiceLanguage) items.push(`Voice: ${customizations.voiceLanguage}`);
    if (customizations.specialRequests) items.push(`Special: ${customizations.specialRequests}`);

    return items.length > 0 ? items : ['Standard configuration'];
  };

  const canUpdateStatus = (currentStatus: string, newStatus: string) => {
    const statusFlow = {
      'pending': ['accepted', 'cancelled'],
      'accepted': ['in_production', 'cancelled'],
      'in_production': ['shipped', 'cancelled'],
      'shipped': ['delivered'],
      'delivered': [],
      'cancelled': []
    };

    return statusFlow[currentStatus as keyof typeof statusFlow]?.includes(newStatus) || false;
  };

  if (orders.length === 0) {
    return (
      <Card className={className}>
        <CardContent className="p-12 text-center">
          <Package className="mx-auto mb-4 text-gray-400" size={48} />
          <h3 className="text-xl font-semibold text-gray-600 mb-2">
            {isVendor ? 'No customer orders' : 'No orders found'}
          </h3>
          <p className="text-gray-500">
            {isVendor 
              ? 'Customer orders will appear here when they request your products.' 
              : 'Your orders will appear here once you place them.'}
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className={className}>
      {/* Mobile View */}
      <div className="md:hidden space-y-4">
        {orders.map((order) => (
          <Card key={order.id}>
            <CardContent className="p-4">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="font-semibold text-sm">
                    #{order.id.slice(0, 8)}
                  </div>
                  <div className="text-xs text-gray-500">
                    {formatDate(order.createdAt)}
                  </div>
                </div>
                <Badge className={getStatusColor(order.status)}>
                  {order.status.replace('_', ' ').charAt(0).toUpperCase() + order.status.slice(1)}
                </Badge>
              </div>

              <div className="space-y-2 mb-3">
                <div className="text-sm">
                  <span className="font-medium">Amount:</span> {formatPrice(order.finalCost || order.estimatedCost)}
                </div>
                {order.deadline && (
                  <div className="text-sm">
                    <span className="font-medium">Deadline:</span> {formatDate(order.deadline)}
                  </div>
                )}
              </div>

              <div className="flex space-x-2">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm" className="flex-1">
                      <Eye className="mr-1" size={14} />
                      View
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl">
                    <DialogHeader>
                      <DialogTitle>Order Details #{order.id.slice(0, 8)}</DialogTitle>
                    </DialogHeader>
                    <OrderDetailsContent order={order} isVendor={isVendor} />
                  </DialogContent>
                </Dialog>

                {isVendor && order.status === 'pending' && (
                  <Button 
                    size="sm" 
                    className="bg-green-500 hover:bg-green-600"
                    onClick={() => handleAcceptOrder(order)}
                  >
                    Accept
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Desktop View */}
      <div className="hidden md:block overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Order</TableHead>
              {!isVendor && <TableHead>Product</TableHead>}
              <TableHead>Requirements</TableHead>
              <TableHead>Pricing</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {orders.map((order) => (
              <TableRow key={order.id}>
                <TableCell>
                  <div>
                    <div className="font-medium">#{order.id.slice(0, 8)}</div>
                    {!isVendor && (
                      <div className="text-sm text-gray-500">
                        Vendor: {order.vendorId?.slice(0, 8) || 'Pending'}
                      </div>
                    )}
                    {isVendor && (
                      <div className="text-sm text-gray-500">
                        Customer: {order.customerId?.slice(0, 8)}
                      </div>
                    )}
                  </div>
                </TableCell>

                {!isVendor && (
                  <TableCell>
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-gray-200 rounded-lg mr-3 flex items-center justify-center">
                        <Package size={16} className="text-gray-500" />
                      </div>
                      <div>
                        <div className="font-medium text-sm">
                          Product ID: {order.productId?.slice(0, 8)}
                        </div>
                        <Badge className={getPriorityColor(order.customizations)}>
                          {order.customizations && Object.keys(order.customizations).length > 0 
                            ? 'Custom' : 'Standard'}
                        </Badge>
                      </div>
                    </div>
                  </TableCell>
                )}

                <TableCell>
                  <div className="max-w-xs">
                    <ul className="list-disc list-inside space-y-1 text-sm">
                      {getCustomizationsList(order.customizations).slice(0, 3).map((item, index) => (
                        <li key={index} className="text-gray-700">{item}</li>
                      ))}
                    </ul>
                    {order.notes && (
                      <div className="text-xs text-gray-500 mt-2">
                        Note: {order.notes.slice(0, 50)}...
                      </div>
                    )}
                  </div>
                </TableCell>

                <TableCell>
                  <div>
                    <div className="font-medium">
                      {formatPrice(order.finalCost || order.estimatedCost)}
                    </div>
                    {order.estimatedCost && order.finalCost && (
                      <div className="text-xs text-gray-500">
                        Est: {formatPrice(order.estimatedCost)}
                      </div>
                    )}
                  </div>
                </TableCell>

                <TableCell>
                  <Badge className={getStatusColor(order.status)}>
                    {order.status.replace('_', ' ').charAt(0).toUpperCase() + order.status.slice(1)}
                  </Badge>
                  {order.deadline && (
                    <div className="text-xs text-gray-500 mt-1">
                      Due: {formatDate(order.deadline)}
                    </div>
                  )}
                </TableCell>

                <TableCell>
                  <div className="text-sm">
                    {formatDate(order.createdAt)}
                  </div>
                </TableCell>

                <TableCell>
                  <div className="flex items-center space-x-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm">
                          <Eye className="mr-1" size={14} />
                          View
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-4xl">
                        <DialogHeader>
                          <DialogTitle>Order Details #{order.id.slice(0, 8)}</DialogTitle>
                        </DialogHeader>
                        <OrderDetailsContent order={order} isVendor={isVendor} />
                      </DialogContent>
                    </Dialog>

                    {isVendor ? (
                      // Vendor Actions
                      <>
                        {order.status === 'pending' && (
                          <div className="flex space-x-1">
                            <Button 
                              size="sm" 
                              className="bg-green-500 hover:bg-green-600"
                              onClick={() => handleAcceptOrder(order)}
                            >
                              <CheckCircle className="mr-1" size={14} />
                              Accept
                            </Button>
                            <Button 
                              size="sm" 
                              variant="destructive"
                              onClick={() => handleStatusUpdate(order.id, 'cancelled')}
                            >
                              <XCircle className="mr-1" size={14} />
                              Decline
                            </Button>
                          </div>
                        )}
                        
                        {order.status === 'accepted' && (
                          <Button 
                            size="sm" 
                            className="bg-blue-500 hover:bg-blue-600"
                            onClick={() => handleStatusUpdate(order.id, 'in_production')}
                          >
                            Start Production
                          </Button>
                        )}
                        
                        {order.status === 'in_production' && (
                          <Button 
                            size="sm" 
                            className="bg-purple-500 hover:bg-purple-600"
                            onClick={() => handleStatusUpdate(order.id, 'shipped')}
                          >
                            <Truck className="mr-1" size={14} />
                            Ship
                          </Button>
                        )}
                        
                        {order.status === 'shipped' && (
                          <Button 
                            size="sm" 
                            className="bg-green-500 hover:bg-green-600"
                            onClick={() => handleStatusUpdate(order.id, 'delivered')}
                          >
                            Mark Delivered
                          </Button>
                        )}
                      </>
                    ) : (
                      // Customer Actions
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="outline" size="sm">
                            <MoreVertical size={14} />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent>
                          <DropdownMenuItem>
                            <MessageSquare className="mr-2" size={14} />
                            Message Vendor
                          </DropdownMenuItem>
                          {order.status === 'delivered' && (
                            <DropdownMenuItem>
                              <Star className="mr-2" size={14} />
                              Leave Review
                            </DropdownMenuItem>
                          )}
                          {['shipped', 'in_production'].includes(order.status) && (
                            <DropdownMenuItem>
                              <Truck className="mr-2" size={14} />
                              Track Order
                            </DropdownMenuItem>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Pricing Modal for Vendors */}
      <Dialog open={showPricingModal} onOpenChange={setShowPricingModal}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Set Pricing & Timeline</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="materials">Materials Cost ($)</Label>
                <Input
                  id="materials"
                  type="number"
                  value={pricing.materials}
                  onChange={(e) => setPricing(prev => ({ ...prev, materials: e.target.value }))}
                  placeholder="680"
                />
              </div>
              
              <div>
                <Label htmlFor="labor">Labor Cost ($)</Label>
                <Input
                  id="labor"
                  type="number"
                  value={pricing.labor}
                  onChange={(e) => setPricing(prev => ({ ...prev, labor: e.target.value }))}
                  placeholder="420"
                />
              </div>
              
              <div>
                <Label htmlFor="aiComponents">AI Components ($)</Label>
                <Input
                  id="aiComponents"
                  type="number"
                  value={pricing.aiComponents}
                  onChange={(e) => setPricing(prev => ({ ...prev, aiComponents: e.target.value }))}
                  placeholder="550"
                />
              </div>
              
              <div>
                <Label htmlFor="shipping">Shipping ($)</Label>
                <Input
                  id="shipping"
                  type="number"
                  value={pricing.shipping}
                  onChange={(e) => setPricing(prev => ({ ...prev, shipping: e.target.value }))}
                  placeholder="150"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="deadline">Delivery Deadline</Label>
              <Input
                id="deadline"
                type="date"
                value={pricing.deadline}
                onChange={(e) => setPricing(prev => ({ ...prev, deadline: e.target.value }))}
                min={new Date().toISOString().split('T')[0]}
              />
            </div>

            <div>
              <Label htmlFor="notes">Additional Notes</Label>
              <Textarea
                id="notes"
                value={pricing.notes}
                onChange={(e) => setPricing(prev => ({ ...prev, notes: e.target.value }))}
                placeholder="Any special considerations or timeline details..."
                rows={3}
              />
            </div>

            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex justify-between items-center">
                <span className="font-semibold">Total Estimated Cost:</span>
                <span className="text-xl font-bold text-primary-500">
                  {formatPrice(
                    parseFloat(pricing.materials || '0') + 
                    parseFloat(pricing.labor || '0') + 
                    parseFloat(pricing.aiComponents || '0') + 
                    parseFloat(pricing.shipping || '0')
                  )}
                </span>
              </div>
            </div>

            <div className="flex space-x-3">
              <Button 
                onClick={handleSubmitPricing}
                className="flex-1 bg-green-500 hover:bg-green-600"
              >
                Accept Order
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setShowPricingModal(false)}
                className="flex-1"
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// Order Details Component
function OrderDetailsContent({ order, isVendor }: { order: Order; isVendor: boolean }) {
  return (
    <div className="space-y-6">
      {/* Order Header */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <Label className="text-sm font-medium text-gray-500">Order ID</Label>
          <p className="font-mono text-sm">{order.id}</p>
        </div>
        <div>
          <Label className="text-sm font-medium text-gray-500">Status</Label>
          <Badge className={`mt-1`}>
            {order.status.replace('_', ' ').charAt(0).toUpperCase() + order.status.slice(1)}
          </Badge>
        </div>
        <div>
          <Label className="text-sm font-medium text-gray-500">Created</Label>
          <p className="text-sm">{new Date(order.createdAt).toLocaleDateString()}</p>
        </div>
      </div>

      {/* Pricing Information */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardContent className="p-4">
            <h4 className="font-semibold mb-3 flex items-center">
              <DollarSign className="mr-2" size={16} />
              Pricing Details
            </h4>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Estimated Cost:</span>
                <span className="font-medium">
                  {order.estimatedCost ? `$${parseFloat(order.estimatedCost).toLocaleString()}` : 'TBD'}
                </span>
              </div>
              {order.finalCost && (
                <div className="flex justify-between">
                  <span>Final Cost:</span>
                  <span className="font-medium text-green-600">
                    ${parseFloat(order.finalCost).toLocaleString()}
                  </span>
                </div>
              )}
              {order.deadline && (
                <div className="flex justify-between">
                  <span>Deadline:</span>
                  <span className="font-medium">
                    {new Date(order.deadline).toLocaleDateString()}
                  </span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <h4 className="font-semibold mb-3 flex items-center">
              <Package className="mr-2" size={16} />
              Product Details
            </h4>
            <div className="space-y-2">
              <div>
                <span className="text-sm text-gray-500">Product ID:</span>
                <p className="font-mono text-sm">{order.productId}</p>
              </div>
              {!isVendor && (
                <div>
                  <span className="text-sm text-gray-500">Vendor:</span>
                  <p className="font-mono text-sm">{order.vendorId}</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Customizations */}
      {order.customizations && (
        <Card>
          <CardContent className="p-4">
            <h4 className="font-semibold mb-3 flex items-center">
              <FileText className="mr-2" size={16} />
              Customization Requirements
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {Object.entries(order.customizations).map(([key, value]) => (
                <div key={key}>
                  <span className="text-sm text-gray-500 capitalize">
                    {key.replace(/([A-Z])/g, ' $1').trim()}:
                  </span>
                  <p className="font-medium">{value as string}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Notes */}
      {order.notes && (
        <Card>
          <CardContent className="p-4">
            <h4 className="font-semibold mb-3">Additional Notes</h4>
            <p className="text-gray-700">{order.notes}</p>
          </CardContent>
        </Card>
      )}

      {/* Contact & Communication */}
      <Card>
        <CardContent className="p-4">
          <h4 className="font-semibold mb-3 flex items-center">
            <MessageSquare className="mr-2" size={16} />
            Communication
          </h4>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm">
              <MessageSquare className="mr-2" size={14} />
              Send Message
            </Button>
            <Button variant="outline" size="sm">
              <Phone className="mr-2" size={14} />
              Request Call
            </Button>
            {order.status === 'shipped' && (
              <Button variant="outline" size="sm">
                <MapPin className="mr-2" size={14} />
                Track Package
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
