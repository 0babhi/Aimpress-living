import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import Navigation from "@/components/navigation";
import OrderTable from "@/components/order-table";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import {
  ShoppingCart,
  DollarSign,
  Package,
  Star,
  TrendingUp,
  Plus,
  Calculator,
  AlertTriangle,
  CheckCircle,
  Clock,
  Users,
  BarChart3
} from "lucide-react";

export default function VendorDashboard() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [newProduct, setNewProduct] = useState({
    name: '',
    description: '',
    category: '',
    basePrice: '',
    materials: {},
    aiFeatures: [] as string[],
    imageUrls: [] as string[],
    voiceCommands: [] as string[],
  });

  const [materialCalculator, setMaterialCalculator] = useState({
    productType: '',
    materialType: '',
    dimensions: '',
    aiFeatures: [] as string[],
  });

  // Fetch vendor profile
  const { data: vendor, isLoading: vendorLoading } = useQuery({
    queryKey: ['/api/vendor/profile'],
    enabled: isAuthenticated,
    retry: false,
  });

  // Fetch vendor orders
  const { data: orders = [], isLoading: ordersLoading } = useQuery({
    queryKey: ['/api/orders'],
    enabled: isAuthenticated,
  });

  // Fetch vendor products
  const { data: products = [], isLoading: productsLoading } = useQuery({
    queryKey: ['/api/products', 'vendor'],
    queryFn: async () => {
      if (!vendor?.id) return [];
      const response = await fetch(`/api/products?vendorId=${vendor.id}`);
      if (!response.ok) throw new Error('Failed to fetch products');
      return response.json();
    },
    enabled: !!vendor?.id,
  });

  // Create vendor profile mutation
  const createVendorMutation = useMutation({
    mutationFn: async (vendorData: any) => {
      const response = await apiRequest('POST', '/api/vendors', vendorData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Vendor Profile Created!",
        description: "Welcome to the AImpress Living marketplace.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/vendor/profile'] });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Failed to create vendor profile",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Create product mutation
  const createProductMutation = useMutation({
    mutationFn: async (productData: any) => {
      const response = await apiRequest('POST', '/api/products', productData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Product Created!",
        description: "Your product has been added to the marketplace.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      setNewProduct({
        name: '',
        description: '',
        category: '',
        basePrice: '',
        materials: {},
        aiFeatures: [],
        imageUrls: [],
        voiceCommands: [],
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Failed to create product",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [isAuthenticated, isLoading, toast]);

  const handleCreateVendor = (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    
    createVendorMutation.mutate({
      businessName: formData.get('businessName'),
      description: formData.get('description'),
      specialties: formData.get('specialties')?.toString().split(',').map(s => s.trim()),
    });
  };

  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    createProductMutation.mutate(newProduct);
  };

  const calculateMaterialCost = () => {
    let baseCost = 0;
    let aiCost = 0;
    let laborCost = 0;

    // Base material costs (simplified)
    switch (materialCalculator.materialType) {
      case 'oak':
        baseCost = 680;
        break;
      case 'walnut':
        baseCost = 850;
        break;
      case 'steel':
        baseCost = 420;
        break;
      case 'carbon':
        baseCost = 1200;
        break;
      default:
        baseCost = 500;
    }

    // AI feature costs
    materialCalculator.aiFeatures.forEach(feature => {
      switch (feature) {
        case 'voice_control':
          aiCost += 150;
          break;
        case 'movement':
          aiCost += 280;
          break;
        case 'smart_sensing':
          aiCost += 120;
          break;
        case 'biometric':
          aiCost += 200;
          break;
      }
    });

    // Labor cost (20-30% of materials + AI)
    laborCost = (baseCost + aiCost) * 0.25;

    return {
      materials: baseCost,
      aiComponents: aiCost,
      labor: Math.round(laborCost),
      total: Math.round(baseCost + aiCost + laborCost),
    };
  };

  const vendorStats = {
    newOrders: orders.filter(o => o.status === 'pending').length,
    revenue: orders.reduce((sum, order) => sum + parseFloat(order.finalCost || order.estimatedCost || '0'), 0),
    activeProducts: products.filter(p => p.isActive).length,
    rating: vendor?.rating ? parseFloat(vendor.rating) : 0,
  };

  const inventoryItems = [
    { name: 'Oak Wood Sheets', available: 45, cost: 28, status: 'in_stock', level: 75 },
    { name: 'Voice Control Modules', available: 8, cost: 150, status: 'low_stock', level: 25 },
    { name: 'Movement Motors', available: 0, cost: 280, status: 'out_of_stock', level: 0 },
    { name: 'Smart Sensors', available: 23, cost: 120, status: 'in_stock', level: 60 },
  ];

  if (isLoading || vendorLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <div className="container mx-auto px-6 py-8">
          <div className="spinner mx-auto"></div>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  // Show vendor registration form if no vendor profile exists
  if (!vendor) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <div className="container mx-auto px-6 py-8">
          <Card className="max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle>Become a Vendor</CardTitle>
              <p className="text-gray-600">
                Join the AImpress Living marketplace and start selling your AI-powered furniture.
              </p>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleCreateVendor} className="space-y-6">
                <div>
                  <Label htmlFor="businessName">Business Name</Label>
                  <Input
                    id="businessName"
                    name="businessName"
                    placeholder="Your business name"
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="description">Business Description</Label>
                  <Textarea
                    id="description"
                    name="description"
                    placeholder="Tell us about your business and expertise..."
                    rows={4}
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="specialties">Specialties</Label>
                  <Input
                    id="specialties"
                    name="specialties"
                    placeholder="e.g., Smart Tables, AI Chairs, Voice Control"
                  />
                  <p className="text-sm text-gray-500 mt-1">
                    Separate multiple specialties with commas
                  </p>
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full bg-accent-coral hover:bg-red-600"
                  disabled={createVendorMutation.isPending}
                >
                  {createVendorMutation.isPending ? 'Creating Profile...' : 'Create Vendor Profile'}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      {/* Header */}
      <section className="bg-white border-b">
        <div className="container mx-auto px-6 py-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Vendor Dashboard</h1>
              <p className="text-gray-600 mt-2">
                Manage your AI furniture orders, inventory, and customer requirements
              </p>
            </div>
            <Badge className="bg-green-100 text-green-800">
              Vendor ID: {vendor.id.slice(0, 8)}
            </Badge>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-6 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm">New Orders</p>
                  <p className="text-3xl font-bold text-primary-500">{vendorStats.newOrders}</p>
                </div>
                <div className="bg-accent-coral p-3 rounded-full">
                  <ShoppingCart className="text-white" size={20} />
                </div>
              </div>
              <div className="mt-4">
                <span className="text-green-600 text-sm">+12% from last week</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm">Revenue</p>
                  <p className="text-3xl font-bold text-primary-500">
                    ${vendorStats.revenue.toLocaleString()}
                  </p>
                </div>
                <div className="bg-green-500 p-3 rounded-full">
                  <DollarSign className="text-white" size={20} />
                </div>
              </div>
              <div className="mt-4">
                <span className="text-green-600 text-sm">+8% from last month</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm">Active Products</p>
                  <p className="text-3xl font-bold text-primary-500">{vendorStats.activeProducts}</p>
                </div>
                <div className="bg-blue-500 p-3 rounded-full">
                  <Package className="text-white" size={20} />
                </div>
              </div>
              <div className="mt-4">
                <span className="text-gray-600 text-sm">3 pending approval</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm">Customer Rating</p>
                  <p className="text-3xl font-bold text-primary-500">{vendorStats.rating.toFixed(1)}</p>
                </div>
                <div className="bg-yellow-500 p-3 rounded-full">
                  <Star className="text-white" size={20} />
                </div>
              </div>
              <div className="mt-4">
                <span className="text-green-600 text-sm">Based on {vendor.reviewCount} reviews</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="orders" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="orders">Orders</TabsTrigger>
            <TabsTrigger value="products">Products</TabsTrigger>
            <TabsTrigger value="calculator">Calculator</TabsTrigger>
            <TabsTrigger value="inventory">Inventory</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="orders" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Customer Orders Requiring Action</CardTitle>
                <p className="text-gray-600">
                  Review and respond to customer orders with pricing and timelines
                </p>
              </CardHeader>
              <CardContent>
                {ordersLoading ? (
                  <div className="spinner mx-auto"></div>
                ) : (
                  <OrderTable orders={orders} isVendor={true} />
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="products" className="mt-6">
            <div className="space-y-6">
              {/* Add New Product */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Plus className="mr-2" size={20} />
                    Add New Product
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleCreateProduct} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="name">Product Name</Label>
                        <Input
                          id="name"
                          value={newProduct.name}
                          onChange={(e) => setNewProduct(prev => ({ ...prev, name: e.target.value }))}
                          placeholder="e.g., SmartTable Pro X1"
                          required
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor="category">Category</Label>
                        <Select value={newProduct.category} onValueChange={(value) => 
                          setNewProduct(prev => ({ ...prev, category: value }))
                        }>
                          <SelectTrigger>
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="tables">Tables</SelectItem>
                            <SelectItem value="chairs">Chairs</SelectItem>
                            <SelectItem value="storage">Storage</SelectItem>
                            <SelectItem value="lighting">Lighting</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label htmlFor="basePrice">Base Price ($)</Label>
                        <Input
                          id="basePrice"
                          type="number"
                          value={newProduct.basePrice}
                          onChange={(e) => setNewProduct(prev => ({ ...prev, basePrice: e.target.value }))}
                          placeholder="1299"
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="description">Description</Label>
                      <Textarea
                        id="description"
                        value={newProduct.description}
                        onChange={(e) => setNewProduct(prev => ({ ...prev, description: e.target.value }))}
                        placeholder="Describe your AI-powered furniture..."
                        rows={3}
                        required
                      />
                    </div>

                    <Button 
                      type="submit" 
                      className="bg-accent-coral hover:bg-red-600"
                      disabled={createProductMutation.isPending}
                    >
                      {createProductMutation.isPending ? 'Creating...' : 'Add Product'}
                    </Button>
                  </form>
                </CardContent>
              </Card>

              {/* Existing Products */}
              <Card>
                <CardHeader>
                  <CardTitle>Your Products</CardTitle>
                </CardHeader>
                <CardContent>
                  {productsLoading ? (
                    <div className="spinner mx-auto"></div>
                  ) : products.length === 0 ? (
                    <div className="text-center py-8">
                      <Package className="mx-auto mb-4 text-gray-400" size={48} />
                      <p className="text-gray-600">No products yet. Add your first product above!</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {products.map((product: any) => (
                        <div key={product.id} className="flex items-center justify-between p-4 border rounded-lg">
                          <div>
                            <h4 className="font-semibold">{product.name}</h4>
                            <p className="text-sm text-gray-600">{product.category}</p>
                            <p className="text-lg font-bold text-primary-500">
                              ${parseFloat(product.basePrice).toLocaleString()}
                            </p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge variant={product.isActive ? "default" : "secondary"}>
                              {product.isActive ? "Active" : "Inactive"}
                            </Badge>
                            <Button variant="outline" size="sm">
                              Edit
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="calculator" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Calculator className="mr-2" size={20} />
                    Materials Calculator
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="productType">Product Type</Label>
                    <Select value={materialCalculator.productType} onValueChange={(value) => 
                      setMaterialCalculator(prev => ({ ...prev, productType: value }))
                    }>
                      <SelectTrigger>
                        <SelectValue placeholder="Select product type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="table">Smart Table</SelectItem>
                        <SelectItem value="chair">Smart Chair</SelectItem>
                        <SelectItem value="storage">Smart Storage</SelectItem>
                        <SelectItem value="lighting">Smart Lighting</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="materialType">Material Type</Label>
                    <Select value={materialCalculator.materialType} onValueChange={(value) => 
                      setMaterialCalculator(prev => ({ ...prev, materialType: value }))
                    }>
                      <SelectTrigger>
                        <SelectValue placeholder="Select material" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="oak">Oak Wood</SelectItem>
                        <SelectItem value="walnut">Walnut Wood</SelectItem>
                        <SelectItem value="steel">Steel Frame</SelectItem>
                        <SelectItem value="carbon">Carbon Fiber</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="dimensions">Dimensions (L x W x H)</Label>
                    <Input
                      id="dimensions"
                      value={materialCalculator.dimensions}
                      onChange={(e) => setMaterialCalculator(prev => ({ ...prev, dimensions: e.target.value }))}
                      placeholder="48 x 24 x 30 inches"
                    />
                  </div>

                  <div>
                    <Label>AI Features</Label>
                    <div className="space-y-2 mt-2">
                      {['voice_control', 'movement', 'smart_sensing', 'biometric'].map((feature) => (
                        <label key={feature} className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            checked={materialCalculator.aiFeatures.includes(feature)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setMaterialCalculator(prev => ({
                                  ...prev,
                                  aiFeatures: [...prev.aiFeatures, feature]
                                }));
                              } else {
                                setMaterialCalculator(prev => ({
                                  ...prev,
                                  aiFeatures: prev.aiFeatures.filter(f => f !== feature)
                                }));
                              }
                            }}
                            className="rounded"
                          />
                          <span className="text-sm">
                            {feature.replace('_', ' ').charAt(0).toUpperCase() + feature.slice(1)}
                            {feature === 'voice_control' && ' (+$150)'}
                            {feature === 'movement' && ' (+$280)'}
                            {feature === 'smart_sensing' && ' (+$120)'}
                            {feature === 'biometric' && ' (+$200)'}
                          </span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <Button 
                    className="w-full bg-accent-coral hover:bg-red-600"
                    onClick={() => {
                      const costs = calculateMaterialCost();
                      toast({
                        title: "Cost Calculated",
                        description: `Total estimated cost: $${costs.total}`,
                      });
                    }}
                  >
                    Calculate Total Cost
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Estimated Cost Breakdown</CardTitle>
                </CardHeader>
                <CardContent>
                  {materialCalculator.materialType ? (
                    <div className="space-y-4">
                      {(() => {
                        const costs = calculateMaterialCost();
                        return (
                          <>
                            <div className="space-y-2">
                              <div className="flex justify-between">
                                <span>Materials:</span>
                                <span>${costs.materials}</span>
                              </div>
                              <div className="flex justify-between">
                                <span>AI Components:</span>
                                <span>${costs.aiComponents}</span>
                              </div>
                              <div className="flex justify-between">
                                <span>Labor:</span>
                                <span>${costs.labor}</span>
                              </div>
                              <Separator />
                              <div className="flex justify-between font-semibold text-lg">
                                <span>Total:</span>
                                <span className="text-primary-500">${costs.total}</span>
                              </div>
                            </div>
                            
                            <div className="bg-blue-50 p-4 rounded-lg">
                              <p className="text-sm text-blue-800">
                                💡 This is an estimated cost. Adjust pricing based on complexity, 
                                custom requirements, and market conditions.
                              </p>
                            </div>
                          </>
                        );
                      })()}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Calculator className="mx-auto mb-4 text-gray-400" size={48} />
                      <p className="text-gray-600">Select materials to see cost breakdown</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="inventory" className="mt-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Inventory Management</CardTitle>
                  <Button className="bg-primary-500 hover:bg-primary-600">
                    <Plus className="mr-2" size={16} />
                    Order Supplies
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {inventoryItems.map((item, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium text-gray-800">{item.name}</h4>
                        <Badge className={
                          item.status === 'in_stock' ? 'bg-green-100 text-green-800' :
                          item.status === 'low_stock' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-red-100 text-red-800'
                        }>
                          {item.status === 'in_stock' ? 'In Stock' :
                           item.status === 'low_stock' ? 'Low Stock' : 'Out of Stock'}
                        </Badge>
                      </div>
                      <div className="flex justify-between text-sm text-gray-600 mb-3">
                        <span>Available: {item.available} units</span>
                        <span>Cost: ${item.cost}/unit</span>
                      </div>
                      <Progress value={item.level} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BarChart3 className="mr-2" size={20} />
                    Sales Analytics
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span>This Month</span>
                      <span className="font-semibold">${vendorStats.revenue.toLocaleString()}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Orders Completed</span>
                      <span className="font-semibold">{orders.filter(o => o.status === 'delivered').length}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Average Order Value</span>
                      <span className="font-semibold">
                        ${orders.length > 0 ? (vendorStats.revenue / orders.length).toFixed(0) : '0'}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Users className="mr-2" size={20} />
                    Customer Insights
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span>Total Customers</span>
                      <span className="font-semibold">{new Set(orders.map(o => o.customerId)).size}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Repeat Customers</span>
                      <span className="font-semibold">
                        {orders.reduce((acc, order) => {
                          const customerOrders = orders.filter(o => o.customerId === order.customerId).length;
                          return customerOrders > 1 ? acc + 1 : acc;
                        }, 0)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Customer Rating</span>
                      <span className="font-semibold">{vendorStats.rating.toFixed(1)}/5.0</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
