import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import {
  X,
  Camera,
  RotateCcw,
  Move,
  ZoomIn,
  ZoomOut,
  Download,
  Share2,
  Settings,
  Play,
  Square,
  RefreshCw
} from "lucide-react";
import type { Product } from "@shared/schema";

interface ARViewerProps {
  product: Product;
  onClose: () => void;
}

export default function ARViewer({ product, onClose }: ARViewerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isARActive, setIsARActive] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [hasPermission, setHasPermission] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [scale, setScale] = useState(1);
  const [rotation, setRotation] = useState(0);
  const [position, setPosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    initializeCamera();
    return () => {
      stopCamera();
    };
  }, []);

  const initializeCamera = async () => {
    try {
      setIsLoading(true);
      setError(null);

      // Check if the browser supports AR/camera features
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("Camera access is not supported in this browser");
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: 'environment', // Use rear camera for AR
          width: { ideal: 1280 },
          height: { ideal: 720 }
        }
      });

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setHasPermission(true);
        setIsARActive(true);
      }
    } catch (err) {
      console.error('Camera access error:', err);
      setError(err instanceof Error ? err.message : 'Failed to access camera');
    } finally {
      setIsLoading(false);
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setIsARActive(false);
    setHasPermission(false);
  };

  const handleStartRecording = async () => {
    if (!videoRef.current || !videoRef.current.srcObject) return;

    try {
      const stream = videoRef.current.srcObject as MediaStream;
      const mediaRecorder = new MediaRecorder(stream);
      
      setIsRecording(true);
      mediaRecorder.start();

      // Auto-stop recording after 30 seconds
      setTimeout(() => {
        if (mediaRecorder.state === 'recording') {
          mediaRecorder.stop();
          setIsRecording(false);
        }
      }, 30000);

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          // TODO: Handle recorded video data
          toast({
            title: "Recording Saved",
            description: "Your AR demo has been recorded successfully.",
          });
        }
      };
    } catch (err) {
      console.error('Recording error:', err);
      toast({
        title: "Recording Failed",
        description: "Unable to record AR session.",
        variant: "destructive",
      });
    }
  };

  const handleStopRecording = () => {
    setIsRecording(false);
    toast({
      title: "Recording Stopped",
      description: "Your AR session recording has been saved.",
    });
  };

  const handleTakeScreenshot = () => {
    if (!videoRef.current || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const video = videoRef.current;
    const ctx = canvas.getContext('2d');

    if (ctx) {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      
      // Draw the video frame
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      
      // Add product overlay (simplified representation)
      ctx.fillStyle = 'rgba(233, 69, 96, 0.8)';
      ctx.fillRect(canvas.width / 2 - 50, canvas.height / 2 - 50, 100, 100);
      ctx.fillStyle = 'white';
      ctx.font = '16px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(product.name, canvas.width / 2, canvas.height / 2);

      // Convert to blob and download
      canvas.toBlob((blob) => {
        if (blob) {
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `${product.name}-ar-preview.png`;
          a.click();
          URL.revokeObjectURL(url);
          
          toast({
            title: "Screenshot Saved",
            description: "AR preview has been downloaded.",
          });
        }
      });
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${product.name} - AR Preview`,
          text: `Check out this AI furniture in AR: ${product.name}`,
          url: window.location.href,
        });
      } catch (err) {
        console.error('Share failed:', err);
      }
    } else {
      // Fallback: copy link to clipboard
      navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link Copied",
        description: "Product link has been copied to clipboard.",
      });
    }
  };

  const resetPosition = () => {
    setScale(1);
    setRotation(0);
    setPosition({ x: 0, y: 0 });
  };

  const handlePlaceFurniture = () => {
    toast({
      title: "Furniture Placed",
      description: `${product.name} has been placed in your space!`,
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-black">
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 z-10 bg-black bg-opacity-50 p-4">
        <div className="flex items-center justify-between text-white">
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="text-white hover:bg-white hover:bg-opacity-20"
            >
              <X size={20} />
            </Button>
            <div>
              <h3 className="font-semibold">{product.name}</h3>
              <p className="text-sm text-gray-300">AR Preview</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Badge className="bg-accent-coral">AR Mode</Badge>
            {isRecording && (
              <Badge className="bg-red-500 animate-pulse">
                <div className="w-2 h-2 bg-white rounded-full mr-2"></div>
                Recording
              </Badge>
            )}
          </div>
        </div>
      </div>

      {/* Main AR View */}
      <div className="relative w-full h-full">
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-75 z-20">
            <div className="text-center text-white">
              <div className="spinner mx-auto mb-4"></div>
              <p>Initializing AR Camera...</p>
            </div>
          </div>
        )}

        {error && (
          <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-75 z-20">
            <Card className="max-w-md mx-4">
              <CardHeader>
                <CardTitle className="text-red-600">Camera Error</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">{error}</p>
                <div className="space-y-2">
                  <Button onClick={initializeCamera} className="w-full">
                    <RefreshCw className="mr-2" size={16} />
                    Retry
                  </Button>
                  <Button variant="outline" onClick={onClose} className="w-full">
                    Close AR Viewer
                  </Button>
                </div>
                <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                  <p className="text-sm text-blue-800">
                    💡 Make sure to allow camera permissions and use HTTPS for AR features.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Video Stream */}
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className="w-full h-full object-cover"
        />

        {/* Hidden canvas for screenshots */}
        <canvas ref={canvasRef} className="hidden" />

        {/* AR Overlay Content */}
        {hasPermission && isARActive && (
          <>
            {/* Crosshair/Target for placing furniture */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="relative">
                <div className="w-16 h-16 border-2 border-white border-opacity-60 rounded-full"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                </div>
              </div>
            </div>

            {/* Product Info Overlay */}
            <div className="absolute bottom-24 left-4 right-4">
              <Card className="bg-black bg-opacity-60 border-white border-opacity-20">
                <CardContent className="p-4 text-white">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-semibold">{product.name}</h4>
                    <Badge variant="outline" className="text-white border-white">
                      {product.category}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-300 mb-3">{product.description}</p>
                  
                  <div className="flex items-center space-x-4 text-sm">
                    <span>Scale: {scale.toFixed(1)}x</span>
                    <span>Rotation: {rotation}°</span>
                    <Button
                      size="sm"
                      variant="outline"
                      className="text-white border-white hover:bg-white hover:text-black"
                      onClick={handlePlaceFurniture}
                    >
                      Place Here
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </>
        )}
      </div>

      {/* Bottom Controls */}
      <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-75 p-4">
        <div className="flex items-center justify-center space-x-4">
          {/* Recording Controls */}
          <Button
            variant="ghost"
            size="sm"
            onClick={isRecording ? handleStopRecording : handleStartRecording}
            className={`text-white hover:bg-white hover:bg-opacity-20 ${
              isRecording ? 'bg-red-500 hover:bg-red-600' : ''
            }`}
          >
            {isRecording ? <Square size={20} /> : <Play size={20} />}
          </Button>

          {/* Screenshot */}
          <Button
            variant="ghost"
            size="sm"
            onClick={handleTakeScreenshot}
            className="text-white hover:bg-white hover:bg-opacity-20"
          >
            <Camera size={20} />
          </Button>

          {/* Controls */}
          <div className="flex items-center space-x-2 bg-white bg-opacity-10 rounded-lg p-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setScale(Math.max(0.5, scale - 0.1))}
              className="text-white hover:bg-white hover:bg-opacity-20"
            >
              <ZoomOut size={16} />
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setRotation((rotation + 45) % 360)}
              className="text-white hover:bg-white hover:bg-opacity-20"
            >
              <RotateCcw size={16} />
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setScale(Math.min(3, scale + 0.1))}
              className="text-white hover:bg-white hover:bg-opacity-20"
            >
              <ZoomIn size={16} />
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={resetPosition}
              className="text-white hover:bg-white hover:bg-opacity-20"
            >
              <RefreshCw size={16} />
            </Button>
          </div>

          {/* Share & Download */}
          <Button
            variant="ghost"
            size="sm"
            onClick={handleShare}
            className="text-white hover:bg-white hover:bg-opacity-20"
          >
            <Share2 size={20} />
          </Button>

          <Button
            variant="ghost"
            size="sm"
            onClick={handleTakeScreenshot}
            className="text-white hover:bg-white hover:bg-opacity-20"
          >
            <Download size={20} />
          </Button>
        </div>
      </div>

      {/* Instructions */}
      {hasPermission && isARActive && (
        <div className="absolute top-20 left-4 right-4">
          <Card className="bg-black bg-opacity-60 border-white border-opacity-20">
            <CardContent className="p-3 text-white">
              <p className="text-sm text-center">
                Point your camera at a flat surface and tap "Place Here" to position the furniture
              </p>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
