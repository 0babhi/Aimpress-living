import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { Heart, Box, Camera, Star, ShoppingCart } from "lucide-react";
import { Product } from "@shared/schema";

interface ProductCardProps {
  product: Product;
  viewMode?: 'grid' | 'list';
}

export default function ProductCard({ product, viewMode = 'grid' }: ProductCardProps) {
  const [isWishlisted, setIsWishlisted] = useState(false);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    // TODO: Implement add to cart functionality
    console.log("Adding to cart:", product.id);
  };

  const handleWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsWishlisted(!isWishlisted);
    // TODO: Implement wishlist functionality
  };

  const handle3DView = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    // TODO: Implement 3D viewer
    console.log("Opening 3D view for:", product.id);
  };

  const handleARView = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    // TODO: Implement AR viewer
    console.log("Opening AR view for:", product.id);
  };

  const formatPrice = (price: string) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(parseFloat(price));
  };

  const getBadgeInfo = () => {
    const badges = [];
    
    if (product.aiFeatures && Array.isArray(product.aiFeatures)) {
      if (product.aiFeatures.includes('voice_control')) {
        badges.push({ text: 'AI Enabled', className: 'bg-accent-coral' });
      }
      if (product.aiFeatures.includes('movement')) {
        badges.push({ text: 'Smart Movement', className: 'bg-blue-500' });
      }
    }

    // Check if it's a new product (created within last 30 days)
    const createdAt = new Date(product.createdAt);
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    if (createdAt > thirtyDaysAgo) {
      badges.push({ text: 'New', className: 'bg-purple-500' });
    }

    // Check if highly rated
    if (parseFloat(product.rating || '0') >= 4.8) {
      badges.push({ text: 'Best Seller', className: 'bg-yellow-500' });
    }

    return badges[0]; // Return the first badge for simplicity
  };

  const badge = getBadgeInfo();

  const imageUrl = product.imageUrls && Array.isArray(product.imageUrls) && product.imageUrls.length > 0
    ? product.imageUrls[0]
    : "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600";

  if (viewMode === 'list') {
    return (
      <Link href={`/products/${product.id}`}>
        <Card className="card-hover cursor-pointer">
          <CardContent className="p-0">
            <div className="flex">
              <div className="relative w-64 h-48 flex-shrink-0">
                <img 
                  src={imageUrl}
                  alt={product.name} 
                  className="w-full h-full object-cover rounded-l-lg"
                />
                {badge && (
                  <Badge className={`absolute top-4 left-4 ${badge.className} text-white`}>
                    {badge.text}
                  </Badge>
                )}
                <Button
                  variant="ghost"
                  size="sm"
                  className={`absolute top-4 right-4 bg-white bg-opacity-80 hover:bg-opacity-100 ${isWishlisted ? 'text-red-500' : 'text-gray-600'}`}
                  onClick={handleWishlist}
                >
                  <Heart size={16} fill={isWishlisted ? 'currentColor' : 'none'} />
                </Button>
              </div>
              
              <div className="flex-1 p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-semibold text-gray-800 mb-2">{product.name}</h3>
                    <p className="text-gray-600 mb-4">{product.description}</p>
                  </div>
                  
                  <div className="text-right">
                    <div className="text-2xl font-bold text-primary-500 mb-1">
                      {formatPrice(product.basePrice)}
                    </div>
                    {badge && (
                      <Badge variant="secondary" className="text-green-600">Best Value</Badge>
                    )}
                  </div>
                </div>

                <div className="flex items-center mb-4">
                  <div className="flex text-yellow-500">
                    {[...Array(5)].map((_, i) => (
                      <Star 
                        key={i} 
                        size={16} 
                        fill={i < Math.floor(parseFloat(product.rating || '0')) ? 'currentColor' : 'none'} 
                      />
                    ))}
                  </div>
                  <span className="text-gray-600 ml-2 text-sm">
                    {product.rating} ({product.reviewCount} reviews)
                  </span>
                </div>

                <div className="space-y-2 mb-4">
                  {product.aiFeatures && Array.isArray(product.aiFeatures) && (
                    <div className="flex flex-wrap gap-2">
                      {product.aiFeatures.slice(0, 3).map((feature) => (
                        <Badge key={feature} variant="outline" className="text-xs">
                          {feature.replace('_', ' ').charAt(0).toUpperCase() + feature.slice(1)}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>

                <div className="flex space-x-2">
                  <Button 
                    className="flex-1 bg-accent-coral hover:bg-red-600"
                    onClick={handleAddToCart}
                  >
                    <ShoppingCart className="mr-2" size={16} />
                    Add to Cart
                  </Button>
                  <Button variant="outline" size="sm" onClick={handle3DView}>
                    <Box className="mr-1" size={16} />
                    3D
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleARView}>
                    <Camera className="mr-1" size={16} />
                    AR
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </Link>
    );
  }

  // Grid view (default)
  return (
    <Link href={`/products/${product.id}`}>
      <Card className="card-hover cursor-pointer">
        <div className="relative">
          <img 
            src={imageUrl}
            alt={product.name} 
            className="w-full h-48 object-cover rounded-t-lg"
          />
          {badge && (
            <Badge className={`absolute top-4 left-4 ${badge.className} text-white`}>
              {badge.text}
            </Badge>
          )}
          <Button
            variant="ghost"
            size="sm"
            className={`absolute top-4 right-4 bg-white bg-opacity-80 hover:bg-opacity-100 ${isWishlisted ? 'text-red-500' : 'text-gray-600'}`}
            onClick={handleWishlist}
          >
            <Heart size={16} fill={isWishlisted ? 'currentColor' : 'none'} />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="absolute bottom-4 right-4 bg-primary-500 text-white hover:bg-primary-600 text-xs"
            onClick={handle3DView}
          >
            <Box className="mr-1" size={14} />
            3D View
          </Button>
        </div>
        
        <CardContent className="p-6">
          <h3 className="text-xl font-semibold text-gray-800 mb-2">{product.name}</h3>
          <p className="text-gray-600 mb-4 line-clamp-2">{product.description}</p>
          
          <div className="flex items-center mb-4">
            <div className="flex text-yellow-500">
              {[...Array(5)].map((_, i) => (
                <Star 
                  key={i} 
                  size={16} 
                  fill={i < Math.floor(parseFloat(product.rating || '0')) ? 'currentColor' : 'none'} 
                />
              ))}
            </div>
            <span className="text-gray-600 ml-2 text-sm">
              {product.rating} ({product.reviewCount} reviews)
            </span>
          </div>

          <div className="flex items-center justify-between mb-4">
            <div className="text-2xl font-bold text-primary-500">
              {formatPrice(product.basePrice)}
            </div>
          </div>

          <div className="space-y-2 mb-4">
            {product.aiFeatures && Array.isArray(product.aiFeatures) && (
              <div className="flex flex-wrap gap-1">
                {product.aiFeatures.slice(0, 2).map((feature) => (
                  <Badge key={feature} variant="outline" className="text-xs">
                    {feature.replace('_', ' ').charAt(0).toUpperCase() + feature.slice(1)}
                  </Badge>
                ))}
              </div>
            )}
          </div>

          <div className="flex space-x-2">
            <Button 
              className="flex-1 bg-accent-coral hover:bg-red-600"
              onClick={handleAddToCart}
            >
              <ShoppingCart className="mr-2" size={16} />
              Add to Cart
            </Button>
            <Button variant="outline" size="sm" onClick={handleARView}>
              <Camera className="mr-1" size={16} />
              AR
            </Button>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
