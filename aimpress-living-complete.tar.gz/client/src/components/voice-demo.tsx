import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Mic, MicOff, Volume2, Play, Pause } from "lucide-react";

export default function VoiceDemo() {
  const [isListening, setIsListening] = useState(false);
  const [currentCommand, setCurrentCommand] = useState("");
  const [demoResponse, setDemoResponse] = useState("");
  const [isPlaying, setIsPlaying] = useState(false);

  const demoCommands = [
    {
      command: "Hey table, come closer",
      response: "Moving table forward 2 feet. Is this position comfortable?",
      animation: "table-move"
    },
    {
      command: "Chair, adjust to work mode",
      response: "Adjusting chair height and back support for optimal work posture.",
      animation: "chair-adjust"
    },
    {
      command: "Set lighting to evening mood",
      response: "Dimming lights to 40% with warm color temperature 2700K.",
      animation: "light-dim"
    },
    {
      command: "Storage unit, show my winter clothes",
      response: "Opening compartment 3 containing your winter wardrobe items.",
      animation: "storage-open"
    }
  ];

  const startListening = () => {
    setIsListening(true);
    setCurrentCommand("");
    setDemoResponse("");
    
    // Simulate voice recognition
    setTimeout(() => {
      const randomCommand = demoCommands[Math.floor(Math.random() * demoCommands.length)];
      setCurrentCommand(randomCommand.command);
      
      setTimeout(() => {
        setDemoResponse(randomCommand.response);
        setIsListening(false);
      }, 2000);
    }, 1000);
  };

  const stopListening = () => {
    setIsListening(false);
    setCurrentCommand("");
    setDemoResponse("");
  };

  const playCommand = (command: string, response: string) => {
    setIsPlaying(true);
    setCurrentCommand(command);
    
    setTimeout(() => {
      setDemoResponse(response);
      setIsPlaying(false);
    }, 1500);
  };

  return (
    <Card className="w-full max-w-md bg-white bg-opacity-10 backdrop-blur-md border-white border-opacity-20">
      <CardContent className="p-6">
        <div className="text-center mb-6">
          <h3 className="text-xl font-bold text-white mb-2">Voice Command Demo</h3>
          <p className="text-primary-100 text-sm">
            Experience AI furniture responding to your voice
          </p>
        </div>

        {/* Main Voice Interface */}
        <div className="text-center mb-6">
          <Button
            size="lg"
            className={`w-20 h-20 rounded-full ${
              isListening 
                ? 'bg-red-500 hover:bg-red-600 voice-pulse' 
                : 'bg-accent-coral hover:bg-red-600'
            }`}
            onClick={isListening ? stopListening : startListening}
            disabled={isPlaying}
          >
            {isListening ? (
              <MicOff className="text-white" size={32} />
            ) : (
              <Mic className="text-white" size={32} />
            )}
          </Button>
          
          <p className="text-white text-sm mt-3">
            {isListening ? "Listening..." : "Tap to speak"}
          </p>
        </div>

        {/* Demo Status */}
        {(currentCommand || demoResponse || isPlaying) && (
          <div className="space-y-3 mb-6">
            {currentCommand && (
              <div className="bg-white bg-opacity-20 rounded-lg p-3">
                <div className="flex items-center mb-2">
                  <Badge className="bg-blue-500 text-white mr-2">You said</Badge>
                  {isListening && <div className="spinner w-4 h-4"></div>}
                </div>
                <p className="text-white text-sm">"{currentCommand}"</p>
              </div>
            )}
            
            {demoResponse && (
              <div className="bg-white bg-opacity-20 rounded-lg p-3">
                <div className="flex items-center mb-2">
                  <Badge className="bg-green-500 text-white mr-2">AI Response</Badge>
                  <Volume2 className="text-white" size={16} />
                </div>
                <p className="text-white text-sm">{demoResponse}</p>
              </div>
            )}
          </div>
        )}

        {/* Quick Commands */}
        <div className="space-y-2">
          <p className="text-white text-sm font-medium mb-3">Try these commands:</p>
          {demoCommands.map((cmd, index) => (
            <div 
              key={index}
              className="flex items-center justify-between p-2 bg-white bg-opacity-10 rounded-lg hover:bg-opacity-20 transition-all cursor-pointer"
              onClick={() => !isPlaying && !isListening && playCommand(cmd.command, cmd.response)}
            >
              <span className="text-white text-sm flex-1">"{cmd.command}"</span>
              <Button
                variant="ghost"
                size="sm"
                className="text-white hover:bg-white hover:bg-opacity-20 ml-2"
                disabled={isPlaying || isListening}
              >
                <Play size={14} />
              </Button>
            </div>
          ))}
        </div>

        {/* Demo Notice */}
        <div className="mt-4 p-3 bg-yellow-500 bg-opacity-20 rounded-lg">
          <p className="text-yellow-100 text-xs text-center">
            🎭 This is a simulation. Real voice control available with purchased furniture.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
